﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;

namespace Weld_Map_to_Feature_Table
{
    public partial class Form1 : Form
    {
        //Global Variables
        private bool clickdragdown;
        private System.Drawing.Point lastLocation;
        System.Data.DataTable DT_Weld_Map = null;
        System.Data.DataTable DT_Ground_Tally = null;
        System.Data.DataTable DT_Prelim = null;
        System.Data.DataTable DT_Filter = null;
        System.Data.DataTable DT_Final = null;
        Boolean freezeoperation = false;


        Worksheet W1 = null; //weldmap
        Worksheet W2 = null; //groundtally

        public Form1()
        {
            InitializeComponent();
        }

        private void button_minimize_Click(object sender, EventArgs e)
        //Minimizes Form
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button_Exit_Click(object sender, EventArgs e)
        //Closes Form
        {
            this.Close();
        }

        private void clickmove_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {

            clickdragdown = true;
            lastLocation = e.Location;
        }

        private void clickmove_MouseMove(object sender, MouseEventArgs e)
        {
            if (clickdragdown)
            {
                this.Location = new System.Drawing.Point(
                  (this.Location.X - lastLocation.X) + e.X, (this.Location.Y - lastLocation.Y) + e.Y);

                this.Update();
            }
        }

        private void clickmove_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            clickdragdown = false;
        }
        public Worksheet Get_active_worksheet_from_Excel_by_index(int index)
        // runs program on defined Excel worksheet 
        {
            try
            {
                Microsoft.Office.Interop.Excel.Application Excel1;
                Microsoft.Office.Interop.Excel.Workbook Workbook1;
                Excel1 = (Microsoft.Office.Interop.Excel.Application)System.Runtime.InteropServices.Marshal.GetActiveObject("Excel.Application");
                if (Excel1 == null) return null;
                Workbook1 = Excel1.ActiveWorkbook;
                if (Workbook1.Worksheets.Count < index)
                {
                    return null;
                }
                return Workbook1.Worksheets[index];
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Excel Not Found");
                //System.Windows.Forms.MessageBox.Show(ex.Message);
                return null;
            }
        }

        private bool IsNumeric(string s)
        // checks to see if value selected is a number.
        {
            bool result1 = false;
            double myNum;

            if (Double.TryParse(s, out myNum))
            {
                result1 = true;
                if (s.Contains(",") == true)
                {
                    result1 = false;
                }
            }
            else
            {
                result1 = false;
            }
            return result1;
        }
        private System.Data.DataTable Populate_data_table_with_excel_range(string table_name, System.Data.DataTable dt1, int row_start, int row_end, int col_start, int col_end, Range header_range, Range range1)
        {
            int nocol1 = col_end - col_start + 1;
            object[,] array_col_names = new object[1, nocol1];
            array_col_names = header_range.Value2;

            for (int i = 1; i <= nocol1; ++i)
            {
                if (array_col_names[1, i] != null)
                {
                    if (dt1.Columns.Contains(array_col_names[1, i].ToString()) == false)
                    {
                        string cell_value = array_col_names[1, i].ToString();
                        dt1.Columns.Add(cell_value.ToString().ToUpper(), typeof(string));
                    }
                    else
                    {
                        MessageBox.Show(table_name + " has 2 headers with the same name.");
                        return null;
                    }
                }
                else
                {
                    MessageBox.Show(table_name + " header is missing values.");
                    return null;
                }
            }

            int nocol = col_end - col_start + 1;
            int norow = row_end - row_start + 1;

            for (int i = 1; i <= norow; ++i)
            {
                dt1.Rows.Add();
            }
            object[,] array_values = new object[norow, nocol];

            array_values = range1.Value2;

            for (int i = 0; i < dt1.Rows.Count; ++i)
            {
                for (int j = 0; j < dt1.Columns.Count; ++j)
                {
                    object Valoare1 = array_values[i + 1, j + 1];
                    if (Valoare1 == null) Valoare1 = DBNull.Value;
                    if (Valoare1 != DBNull.Value && Valoare1 != null)
                    {
                        Valoare1 = Convert.ToString(Valoare1).Replace("-2146826246", "");
                        if (Convert.ToString(Valoare1) == "") Valoare1 = DBNull.Value;
                    }
                    dt1.Rows[i][j] = Valoare1;
                }
            }
            dt1.Columns.Add("reporti", typeof(int));
            return dt1;
        }
        private void button_Scan_Weld_Map_Click(object sender, EventArgs e)
        {
            if (freezeoperation == false)
            {
                freezeoperation = true;
                try
                {
                    DT_Weld_Map = new System.Data.DataTable();


                    string start_row_string = textBox_WM_Start_Row.Text;
                    int start_row = Convert.ToInt32(start_row_string);
                    string end_row_string = textBox_WM_End_Row.Text;
                    int end_row = Convert.ToInt32(end_row_string);
                    string start_colomn_string = textBox_WM_Start_Column.Text;
                    string end_column_string = textBox_WM_End_Column.Text;
                    string wksht = textBox_sht_1.Text;
                    int wksht_int = Convert.ToInt32(wksht);
                    W1 = Get_active_worksheet_from_Excel_by_index(wksht_int);

                    if (IsNumeric(start_row_string) == false)
                    {
                        MessageBox.Show("Start row needs to be a number.");
                        freezeoperation = false;
                        return;
                    }

                    if (IsNumeric(end_row_string) == false)
                    {
                        MessageBox.Show("End row needs to be a number.");
                        freezeoperation = false;
                        return;
                    }

                    if (IsNumeric(wksht) == false)
                    {
                        MessageBox.Show("Worksheet index needs to be a number.");
                        freezeoperation = false;
                        return;
                    }

                    if (wksht_int < 1)
                    {
                        MessageBox.Show("Worksheet Index needs to be bigger than 1.");
                        freezeoperation = false;
                        return;
                    }

                    if (W1 == null)
                    {
                        MessageBox.Show("Worksheet Index you specified doesnt exist.");
                        freezeoperation = false;
                        return;
                    }

                    Range sc_convert_start = W1.Range[start_colomn_string + "1"];
                    Range sc_convert_end = W1.Range[end_column_string + "1"];
                    int start_column = sc_convert_start.Column;
                    int end_column = sc_convert_end.Column;
                    Range Row1 = W1.Range[start_colomn_string + "1" + ":" + end_column_string + "1"];
                    Range range1 = W1.Range[start_colomn_string + start_row_string + ":" + end_column_string + end_row_string];

                    DT_Weld_Map = Populate_data_table_with_excel_range("Weld Map", DT_Weld_Map, start_row, end_row, start_column, end_column, Row1, range1);

                    if (DT_Weld_Map == null)
                    {
                        freezeoperation = false;
                        return;
                    }

                    comboBox_PNT_WM.Items.Clear();
                    checkBox_PNT.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_PNT_WM.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_PNT_WM.Items.Contains("PNT") == true)
                        {
                            comboBox_PNT_WM.SelectedIndex = comboBox_PNT_WM.Items.IndexOf("PNT");
                        }

                        if (comboBox_PNT_WM.Text != "")
                        {
                            checkBox_PNT.Checked = true;
                        }
                    }

                    comboBox_Northing.Items.Clear();
                    checkBox_Northing.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Northing.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Northing.Items.Contains("NORTHING") == true)
                        {
                            comboBox_Northing.SelectedIndex = comboBox_Northing.Items.IndexOf("NORTHING");
                        }

                        if (comboBox_Northing.Text != "")
                        {
                            checkBox_Northing.Checked = true;
                        }
                    }

                    comboBox_Easting.Items.Clear();
                    checkBox_Easting.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Easting.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Easting.Items.Contains("EASTING") == true)
                        {
                            comboBox_Easting.SelectedIndex = comboBox_Easting.Items.IndexOf("EASTING");
                        }

                        if (comboBox_Easting.Text != "")
                        {
                            checkBox_Easting.Checked = true;
                        }

                    }

                    comboBox_Elevation.Items.Clear();
                    checkBox_Elevation.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Elevation.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Elevation.Items.Contains("ELEVATION") == true)
                        {
                            comboBox_Elevation.SelectedIndex = comboBox_Elevation.Items.IndexOf("ELEVATION");
                        }

                        if (comboBox_Elevation.Text != "")
                        {
                            checkBox_Elevation.Checked = true;
                        }
                    }

                    comboBox_Feature_Code.Items.Clear();
                    checkBox_Feature.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Feature_Code.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Feature_Code.Items.Contains("FEATURE_CODE") == true)
                        {
                            comboBox_Feature_Code.SelectedIndex = comboBox_Feature_Code.Items.IndexOf("FEATURE_CODE");
                        }

                        if (comboBox_Feature_Code.Text != "")
                        {
                            checkBox_Feature.Checked = true;
                        }
                    }

                    comboBox_Description.Items.Clear();
                    checkBox_Description.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Description.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Description.Items.Contains("DESCRIPTION") == true)
                        {
                            comboBox_Description.SelectedIndex = comboBox_Description.Items.IndexOf("DESCRIPTION");
                        }

                        if (comboBox_Description.Text != "")
                        {
                            checkBox_Description.Checked = true;
                        }
                    }

                    comboBox_Station.Items.Clear();
                    checkBox_Station.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Station.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Station.Items.Contains("STATION") == true)
                        {
                            comboBox_Station.SelectedIndex = comboBox_Station.Items.IndexOf("STATION");
                        }

                        if (comboBox_Station.Items.Contains("PROJECT_STATION") == true)
                        {
                            comboBox_Station.SelectedIndex = comboBox_Station.Items.IndexOf("PROJECT_STATION");
                        }

                        if (comboBox_Station.Items.Contains("3D-AS-BUILT STATIONING") == true)
                        {
                            comboBox_Station.SelectedIndex = comboBox_Station.Items.IndexOf("3D-AS-BUILT STATIONING");
                        }

                        if (comboBox_Station.Items.Contains("3D_STATION") == true)
                        {
                            comboBox_Station.SelectedIndex = comboBox_Station.Items.IndexOf("3D_STATION");
                        }

                        if (comboBox_Station.Text != "")
                        {
                            checkBox_Station.Checked = true;
                        }

                    }

                    comboBox_MM_Back.Items.Clear();
                    checkBox_MM_Back.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_MM_Back.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_MM_Back.Items.Contains("MM_BK") == true)
                        {
                            comboBox_MM_Back.SelectedIndex = comboBox_MM_Back.Items.IndexOf("MM_BK");
                        }

                        if (comboBox_MM_Back.Text != "")
                        {
                            checkBox_MM_Back.Checked = true;
                        }
                    }

                    comboBox_MM_Ahead.Items.Clear();
                    checkBox_MM_Ahead.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_MM_Ahead.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_MM_Ahead.Items.Contains("MM_AHD") == true)
                        {
                            comboBox_MM_Ahead.SelectedIndex = comboBox_MM_Ahead.Items.IndexOf("MM_AHD");
                        }

                        if (comboBox_MM_Ahead.Text != "")
                        {
                            checkBox_MM_Ahead.Checked = true;
                        }
                    }

                    comboBox_Wall_Back.Items.Clear();
                    checkBox_Wall_Back.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Wall_Back.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Wall_Back.Items.Contains("WALL_BK") == true)
                        {
                            comboBox_Wall_Back.SelectedIndex = comboBox_Wall_Back.Items.IndexOf("WALL_BK");
                        }

                    }

                    comboBox_Wall_Ahead.Items.Clear();
                    checkBox_Wall_Ahead.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Wall_Ahead.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Wall_Ahead.Items.Contains("WALL_AHD") == true)
                        {
                            comboBox_Wall_Ahead.SelectedIndex = comboBox_Wall_Ahead.Items.IndexOf("WALL_AHD");
                        }

                        if (comboBox_Wall_Ahead.Text != "")
                        {
                            checkBox_Wall_Ahead.Checked = true;
                        }

                    }

                    comboBox_Pipe_Back.Items.Clear();
                    checkBox_Pipe_Back.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Pipe_Back.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Pipe_Back.Items.Contains("PIPE_BK") == true)
                        {
                            comboBox_Pipe_Back.SelectedIndex = comboBox_Pipe_Back.Items.IndexOf("PIPE_BK");
                        }
                    }

                    comboBox_Pipe_Ahead.Items.Clear();
                    checkBox_Pipe_Ahead.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Pipe_Ahead.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Pipe_Ahead.Items.Contains("PIPE_AHD") == true)
                        {
                            comboBox_Pipe_Ahead.SelectedIndex = comboBox_Pipe_Ahead.Items.IndexOf("PIPE_AHD");
                        }
                    }

                    comboBox_Heat_Back.Items.Clear();
                    checkBox_Heat_Back.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Heat_Back.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Heat_Back.Items.Contains("HEAT_BK") == true)
                        {
                            comboBox_Heat_Back.SelectedIndex = comboBox_Heat_Back.Items.IndexOf("HEAT_BK");
                        }
                    }

                    comboBox_Heat_Ahead.Items.Clear();
                    checkBox_Heat_Ahead.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Heat_Ahead.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Heat_Ahead.Items.Contains("HEAT_AHD") == true)
                        {
                            comboBox_Heat_Ahead.SelectedIndex = comboBox_Heat_Ahead.Items.IndexOf("HEAT_AHD");
                        }

                        if (comboBox_Heat_Ahead.Text != "")
                        {
                            checkBox_Heat_Ahead.Checked = true;
                        }

                    }

                    comboBox_Coating_Back.Items.Clear();
                    checkBox_Coating_Back.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Coating_Back.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Coating_Back.Items.Contains("COATING BACK") == true)
                        {
                            comboBox_Coating_Back.SelectedIndex = comboBox_Coating_Back.Items.IndexOf("COATING BACK");
                        }

                        if (comboBox_Coating_Back.Items.Contains("COATING_BK") == true)
                        {
                            comboBox_Coating_Back.SelectedIndex = comboBox_Coating_Back.Items.IndexOf("COATING_BK");
                        }

                    }

                    comboBox_Coating_Ahead.Items.Clear();
                    checkBox_Coating_Ahead.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Coating_Ahead.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Coating_Ahead.Items.Contains("COATING AHEAD") == true)
                        {
                            comboBox_Coating_Ahead.SelectedIndex = comboBox_Coating_Ahead.Items.IndexOf("COATING AHEAD");
                        }

                        if (comboBox_Coating_Ahead.Items.Contains("COATING_AHD") == true)
                        {
                            comboBox_Coating_Ahead.SelectedIndex = comboBox_Coating_Ahead.Items.IndexOf("COATING_AHD");
                        }

                        if (comboBox_Coating_Ahead.Text != "")
                        {
                            checkBox_Coating_Ahead.Checked = true;
                        }


                    }

                    comboBox_Grade_Back.Items.Clear();
                    checkBox_Grade_Back.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Grade_Back.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Grade_Back.Items.Contains("GRADE_BK") == true)
                        {
                            comboBox_Grade_Back.SelectedIndex = comboBox_Grade_Back.Items.IndexOf("GRADE_BK");
                        }
                    }

                    comboBox_Grade_Ahead.Items.Clear();
                    checkBox_Grade_Ahead.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Grade_Ahead.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Grade_Ahead.Items.Contains("GRADE_AHD") == true)
                        {
                            comboBox_Grade_Ahead.SelectedIndex = comboBox_Grade_Ahead.Items.IndexOf("GRADE_AHD");
                        }

                        if (comboBox_Grade_Ahead.Text != "")
                        {
                            checkBox_Grade_Ahead.Checked = true;
                        }

                    }

                    comboBox_Length.Items.Clear();
                    checkBox_Length.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Length.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Length.Items.Contains("LENGTH") == true)
                        {
                            comboBox_Length.SelectedIndex = comboBox_Length.Items.IndexOf("LENGTH");
                        }

                        if (comboBox_Length.Text != "")
                        {
                            checkBox_Length.Checked = true;
                        }

                    }



                    comboBox_NG_PNT.Items.Clear();
                    checkBox_NG_PNT.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_NG_PNT.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_NG_PNT.Items.Contains("NG") == true)
                        {
                            comboBox_NG_PNT.SelectedIndex = comboBox_NG_PNT.Items.IndexOf("NG");
                        }
                    }

                    comboBox_NG_Northing.Items.Clear();
                    checkBox_NG_Northing.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_NG_Northing.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_NG_Northing.Items.Contains("NG_NORTHING") == true)
                        {
                            comboBox_NG_Northing.SelectedIndex = comboBox_NG_Northing.Items.IndexOf("NG_NORTHING");
                        }
                    }

                    comboBox_NG_Easting.Items.Clear();
                    checkBox_NG_Easting.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_NG_Easting.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_NG_Easting.Items.Contains("NG_EASTING") == true)
                        {
                            comboBox_NG_Easting.SelectedIndex = comboBox_NG_Easting.Items.IndexOf("NG_EASTING");
                        }
                    }

                    comboBox_NG_Elevation.Items.Clear();
                    checkBox_NG_Elevation.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_NG_Elevation.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_NG_Elevation.Items.Contains("NG_ELEVATION") == true)
                        {
                            comboBox_NG_Elevation.SelectedIndex = comboBox_NG_Elevation.Items.IndexOf("NG_ELEVATION");
                        }
                    }

                    comboBox_Cover.Items.Clear();
                    checkBox_Cover.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Cover.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Cover.Items.Contains("COVER") == true)
                        {
                            comboBox_Cover.SelectedIndex = comboBox_Cover.Items.IndexOf("COVER");
                        }
                    }

                    comboBox_Location.Items.Clear();
                    checkBox_Location.Checked = false;

                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Location.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Location.Items.Contains("LOCATION") == true)
                        {
                            comboBox_Location.SelectedIndex = comboBox_Location.Items.IndexOf("LOCATION");
                        }
                    }

                    comboBox_Bend_Horiz.Items.Clear();
                    checkBox_Bend_Horiz.Checked = false;
                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Bend_Horiz.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Bend_Horiz.Items.Contains("H_ANGLE") == true)
                        {
                            comboBox_Bend_Horiz.SelectedIndex = comboBox_Bend_Horiz.Items.IndexOf("H_ANGLE");
                        }
                    }

                    comboBox_Bend_Vert.Items.Clear();
                    checkBox_Bend_Vert.Checked = false;
                    for (int i = 0; i < DT_Weld_Map.Columns.Count; ++i)
                    {
                        comboBox_Bend_Vert.Items.Add(DT_Weld_Map.Columns[i].ColumnName);
                        if (comboBox_Bend_Vert.Items.Contains("V_ANGLE") == true)
                        {
                            comboBox_Bend_Vert.SelectedIndex = comboBox_Bend_Vert.Items.IndexOf("V_ANGLE");
                        }
                    }



                    //  MessageBox.Show("Weld Map Scan Complete");

                }

                catch (System.Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                freezeoperation = false;
            }
        }
        static public Worksheet Get_NEW_worksheet_from_Excel()
        {
            Microsoft.Office.Interop.Excel.Application Excel1;
            Microsoft.Office.Interop.Excel.Workbook Workbook1;
            try
            {
                Excel1 = (Microsoft.Office.Interop.Excel.Application)System.Runtime.InteropServices.Marshal.GetActiveObject("Excel.Application");
            }
            catch (System.Exception ex)
            {
                Excel1 = new Microsoft.Office.Interop.Excel.Application();
            }

            try
            {
                Excel1.Visible = true;
                Excel1.Workbooks.Add();
                Workbook1 = Excel1.ActiveWorkbook;
                return Workbook1.ActiveSheet;
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
                return null;
            }


        }
        public void Transfer_datatable_to_new_excel_spreadsheet(System.Data.DataTable dt1)
        {
            if (dt1 != null)
            {
                if (dt1.Rows.Count > 0)
                {
                    Microsoft.Office.Interop.Excel.Worksheet W1 = Get_NEW_worksheet_from_Excel();
                    W1.Cells.NumberFormat = "@";
                    int maxRows = dt1.Rows.Count;
                    int maxCols = dt1.Columns.Count;
                    Microsoft.Office.Interop.Excel.Range range1 = W1.Range[W1.Cells[2, 1], W1.Cells[maxRows + 1, maxCols]];
                    object[,] values1 = new object[maxRows, maxCols];

                    for (int i = 0; i < maxRows; ++i)
                    {
                        for (int j = 0; j < maxCols; ++j)
                        {
                            if (dt1.Rows[i][j] != DBNull.Value)
                            {
                                values1[i, j] = dt1.Rows[i][j];
                            }
                        }
                    }

                    for (int i = 0; i < dt1.Columns.Count; ++i)
                    {
                        W1.Cells[1, i + 1].value2 = dt1.Columns[i].ColumnName;
                    }
                    range1.Value2 = values1;
                }
            }
        }
        private void button_Scan_Ground_Tally_Click(object sender, EventArgs e)
        {
            if (freezeoperation == false)
            {
                freezeoperation = true;
                try
                {
                    DT_Ground_Tally = new System.Data.DataTable();

                    string start_row_string = textBox_GT_Start_Row.Text;
                    int start_row = Convert.ToInt32(start_row_string);
                    string end_row_string = textBox_GT_End_Row.Text;
                    int end_row = Convert.ToInt32(end_row_string);
                    string start_colomn_string = textBox_GT_Start_Column.Text;
                    string end_column_string = textBox_GT_End_Column.Text;
                    string wksht = textBox_sht_2.Text;
                    int wksht_int = Convert.ToInt32(wksht);
                    W2 = Get_active_worksheet_from_Excel_by_index(wksht_int);

                    if (IsNumeric(start_row_string) == false)
                    {
                        MessageBox.Show("Start row needs to be a number.");
                        freezeoperation = false;
                        return;
                    }

                    if (IsNumeric(end_row_string) == false)
                    {
                        MessageBox.Show("End row needs to be a number.");
                        freezeoperation = false;
                        return;
                    }

                    if (IsNumeric(wksht) == false)
                    {
                        MessageBox.Show("Worksheet index needs to be a number.");
                        freezeoperation = false;
                        return;
                    }

                    if (wksht_int < 1)
                    {
                        MessageBox.Show("Worksheet Index needs to be bigger than 1.");
                        freezeoperation = false;
                        return;
                    }

                    if (W2 == null)
                    {
                        MessageBox.Show("Worksheet Index you specified doesnt exist.");
                        freezeoperation = false;
                        return;
                    }

                    Range sc_convert_start = W2.Range[start_colomn_string + "1"];
                    Range sc_convert_end = W2.Range[end_column_string + "1"];
                    int start_column = sc_convert_start.Column;
                    int end_column = sc_convert_end.Column;
                    Range Row1 = W2.Range[start_colomn_string + "1" + ":" + end_column_string + "1"];
                    Range range1 = W2.Range[start_colomn_string + start_row_string + ":" + end_column_string + end_row_string];

                    DT_Ground_Tally = Populate_data_table_with_excel_range("Ground Tally", DT_Ground_Tally, start_row, end_row, start_column, end_column, Row1, range1);
                    if (DT_Ground_Tally == null)
                    {
                        freezeoperation = false;
                        return;
                    }

                    comboBox_GT_MM.Items.Clear();
                    checkBox_GT_MM.Checked = false;

                    for (int i = 0; i < DT_Ground_Tally.Columns.Count; ++i)
                    {
                        comboBox_GT_MM.Items.Add(DT_Ground_Tally.Columns[i].ColumnName);
                        if (comboBox_GT_MM.Items.Contains("MM") == true)
                        {
                            comboBox_GT_MM.SelectedIndex = comboBox_GT_MM.Items.IndexOf("MM");
                        }

                    }

                    comboBox_GT_Heat.Items.Clear();
                    checkBox_GT_Heat.Checked = false;

                    for (int i = 0; i < DT_Ground_Tally.Columns.Count; ++i)
                    {
                        comboBox_GT_Heat.Items.Add(DT_Ground_Tally.Columns[i].ColumnName);
                        if (comboBox_GT_Heat.Items.Contains("HEAT") == true)
                        {
                            comboBox_GT_Heat.SelectedIndex = comboBox_GT_Heat.Items.IndexOf("HEAT");
                        }

                    }

                    comboBox_GT_Wall_Thk.Items.Clear();
                    checkBox_GT_Wall_Thk.Checked = false;

                    for (int i = 0; i < DT_Ground_Tally.Columns.Count; ++i)
                    {
                        comboBox_GT_Wall_Thk.Items.Add(DT_Ground_Tally.Columns[i].ColumnName);
                        if (comboBox_GT_Wall_Thk.Items.Contains("WALL_THICKNESS") == true)
                        {
                            comboBox_GT_Wall_Thk.SelectedIndex = comboBox_GT_Wall_Thk.Items.IndexOf("WALL_THICKNESS");
                        }

                    }

                    comboBox_GT_Pipe_DIA.Items.Clear();
                    checkBox_GT_Pipe_DIA.Checked = false;

                    for (int i = 0; i < DT_Ground_Tally.Columns.Count; ++i)
                    {
                        comboBox_GT_Pipe_DIA.Items.Add(DT_Ground_Tally.Columns[i].ColumnName);
                        if (comboBox_GT_Pipe_DIA.Items.Contains("DIAMETER") == true)
                        {
                            comboBox_GT_Pipe_DIA.SelectedIndex = comboBox_GT_Pipe_DIA.Items.IndexOf("DIAMETER");
                        }

                        if (comboBox_GT_Pipe_DIA.Text != "")
                        {
                            checkBox_GT_Pipe_DIA.Checked = true;
                        }
                    }

                    comboBox_GT_Coating.Items.Clear();
                    checkBox_GT_Coating.Checked = false;

                    for (int i = 0; i < DT_Ground_Tally.Columns.Count; ++i)
                    {
                        comboBox_GT_Coating.Items.Add(DT_Ground_Tally.Columns[i].ColumnName);
                        if (comboBox_GT_Coating.Items.Contains("PIPE COATING") == true)
                        {
                            comboBox_GT_Coating.SelectedIndex = comboBox_GT_Coating.Items.IndexOf("PIPE COATING");
                        }

                        if (comboBox_GT_Coating.Items.Contains("COATING") == true)
                        {
                            comboBox_GT_Coating.SelectedIndex = comboBox_GT_Coating.Items.IndexOf("COATING");
                        }

                    }

                    comboBox_GT_Grade.Items.Clear();
                    checkBox_GT_Grade.Checked = false;

                    for (int i = 0; i < DT_Ground_Tally.Columns.Count; ++i)
                    {
                        comboBox_GT_Grade.Items.Add(DT_Ground_Tally.Columns[i].ColumnName);
                        if (comboBox_GT_Grade.Items.Contains("GRADE") == true)
                        {
                            comboBox_GT_Grade.SelectedIndex = comboBox_GT_Grade.Items.IndexOf("GRADE");
                        }

                        if (comboBox_GT_Grade.Text != "" && checkBox_Grade_Ahead.Checked == false)
                        {
                            checkBox_GT_Grade.Checked = true;
                        }

                    }

                    //  MessageBox.Show("Ground Tally Scan Complete");
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                freezeoperation = false;
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            Transfer_datatable_to_new_excel_spreadsheet(DT_Weld_Map);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Transfer_datatable_to_new_excel_spreadsheet(DT_Ground_Tally);
        }
        public Worksheet Get_active_worksheet_from_Excel()
        // runs program on active Excel worksheet 
        {
            try
            {
                Microsoft.Office.Interop.Excel.Application Excel1;
                Microsoft.Office.Interop.Excel.Workbook Workbook1;
                Excel1 = (Microsoft.Office.Interop.Excel.Application)System.Runtime.InteropServices.Marshal.GetActiveObject("Excel.Application");
                if (Excel1 == null) return null;
                Workbook1 = Excel1.ActiveWorkbook;
                return Workbook1.ActiveSheet;
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Excel Not Found");
                //System.Windows.Forms.MessageBox.Show(ex.Message);
                return null;
            }
        }
        private void button6_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel.Worksheet w1 = Get_active_worksheet_from_Excel();
            //MessageBox.Show(w1.Range["L2"].Value2);
            string cell_value = textBox_color_check.Text;

            MessageBox.Show("color " + Convert.ToString(w1.Range[cell_value].Interior.Color) +
               "\n\rcolor index " + Convert.ToString(w1.Range[cell_value].Interior.ColorIndex) +
               "\n\rgradient " + Convert.ToString(w1.Range[cell_value].Interior.Gradient) +
               "\n\rpattern " + Convert.ToString(w1.Range[cell_value].Interior.Pattern) +
               "\n\rpattern color " + Convert.ToString(w1.Range[cell_value].Interior.PatternColor) +
               "\n\rpattern color index " + Convert.ToString(w1.Range[cell_value].Interior.PatternColorIndex) +
               "\n\rpattern theme color " + Convert.ToString(w1.Range[cell_value].Interior.PatternThemeColor) +
               "\n\rpattern tint and shade " + Convert.ToString(w1.Range[cell_value].Interior.PatternTintAndShade) +
               "\n\rtheme color " + Convert.ToString(w1.Range[cell_value].Interior.ThemeColor) +
               "\n\rtint and shade " + Convert.ToString(w1.Range[cell_value].Interior.TintAndShade) +
               "\n\rfont color " + Convert.ToString(w1.Range[cell_value].Font.Color));
        }

        private double Calc_Length(System.Data.DataTable dt1, int i)
        {
            if (dt1 != null && dt1.Columns.Contains(comboBox_Station.Text) && dt1.Columns.Contains(comboBox_Feature_Code.Text))
            {
                string desc = Convert.ToString(dt1.Rows[i][comboBox_Feature_Code.Text]);

                if (desc == "WELD")
                {
                    double STA1 = Convert.ToDouble(dt1.Rows[i][comboBox_Station.Text]);
                    if (i < dt1.Rows.Count - 1)
                    {
                        for (int j = i + 1; j < dt1.Rows.Count; ++j)
                        {
                            string desc2 = Convert.ToString(dt1.Rows[j][comboBox_Feature_Code.Text]);
                            if (desc2 == "WELD")
                            {
                                double STA2 = Convert.ToDouble(dt1.Rows[j][comboBox_Station.Text]);
                                return Math.Round(STA2 - STA1, 2);
                            }
                        }
                    }
                }



            }
            return -1000;
        }
        static public string Get_String_Rounded(double Numar, int Nr_dec)
        {

            String String1, String2, Zero, zero1;
            Zero = "";
            zero1 = "";

            String String_punct = "";

            if (Nr_dec > 0)
            {
                String_punct = ".";
                for (int i = 1; i <= Nr_dec; i = i + 1)
                {
                    Zero = Zero + "0";
                }
            }

            string String_minus = "";

            if (Numar < 0)
            {
                String_minus = "-";
                Numar = -Numar;
            }

            String1 = Math.Round(Numar, Nr_dec, MidpointRounding.AwayFromZero).ToString();

            String2 = String1;

            if (String1.Contains(".") == false)
            {
                String2 = String1 + String_punct + Zero;
                goto end;
            }

            if (String1.Length - String1.IndexOf(".") - 1 - Nr_dec != 0)
            {
                for (int i = 1; i <= String1.IndexOf(".") + 1 + Nr_dec - String1.Length; i = i + 1)
                {
                    zero1 = zero1 + "0";
                }

                String2 = String1 + zero1;
            }

        end:
            return String_minus + String2;

        }

        static public string Get_chainage_from_double(double Numar, string units, int Nr_dec)
        {

            String String2, String3;
            String3 = "";
            String String_minus = "";

            if (Numar < 0)
            {
                String_minus = "-";
                Numar = -Numar;
            }

            String2 = Get_String_Rounded(Numar, Nr_dec);


            int Punct;
            if (String2.Contains(".") == false)
            {
                Punct = 0;
            }
            else
            {
                Punct = 1;
            }


            if (String2.Length - Nr_dec - Punct >= 4)
            {
                if (units == "f") String3 = String2.Substring(0, String2.Length - 2 - Nr_dec - Punct) + "+" + String2.Substring(String2.Length - (2 + Nr_dec + Punct));
                if (units == "m") String3 = String2.Substring(0, String2.Length - 3 - Nr_dec - Punct) + "+" + String2.Substring(String2.Length - (3 + Nr_dec + Punct));
            }
            else
            {
                if (units == "f")
                {
                    if (String2.Length - Nr_dec - Punct == 1) String3 = "0+0" + String2;
                    if (String2.Length - Nr_dec - Punct == 2) String3 = "0+" + String2;
                    if (String2.Length - Nr_dec - Punct == 3) String3 = String2.Substring(0, 1) + "+" + String2.Substring(String2.Length - (2 + Nr_dec + Punct));
                }
                if (units == "m")
                {
                    if (String2.Length - Nr_dec - Punct == 1) String3 = "0+00" + String2;
                    if (String2.Length - Nr_dec - Punct == 2) String3 = "0+0" + String2;
                    if (String2.Length - Nr_dec - Punct == 3) String3 = "0+" + String2;
                }
            }


            return String_minus + String3;

        }

        private void button_Prelim_Feature_Table_Click(object sender, EventArgs e)
        {
            if (freezeoperation == false)
            {
                freezeoperation = true;
                try
                {
                    string PNT = (comboBox_PNT_WM.Text).ToUpper();
                    string Station = "STA DBL";
                    string Northing = "NORTHING";
                    string Easting = "EASTING";
                    string Elevation = "ELEV";
                    string Feature = "DESCRIPTION";
                    string MM_Back = "JT BK";
                    string Description = "XRAY#";
                    string MM_Ahead = "JT AHD";
                    string Heat_Back = comboBox_Heat_Back.Text;
                    string Heat_Ahead = "HEAT#";
                    string Prelim_Length = "INV\r\nLENGTH\r\n(FT)";
                    string Diameter = "DIA\r\n(FT)";
                    string wall_back = comboBox_Wall_Back.Text;
                    string wall_ahead = "THK\r\n(IN)";
                    string pipe_back = comboBox_Pipe_Back.Text;
                    string pipe_ahead = comboBox_Pipe_Ahead.Text;
                    string Grade_BK = comboBox_Grade_Back.Text;
                    string Grade_AHD = "GRADE";
                    string Coating_BK = comboBox_Coating_Back.Text;
                    string Coating_AHD = "COATING";
                    string NG_PNT = comboBox_NG_PNT.Text;
                    string NG_Northing = comboBox_NG_Northing.Text;
                    string NG_Easting = comboBox_NG_Easting.Text;
                    string NG_Elevation = comboBox_NG_Elevation.Text;
                    string cover = comboBox_Cover.Text;
                    string location = comboBox_Location.Text;
                    string Bend_Horiz = comboBox_Bend_Horiz.Text;
                    string Bend_Vert = comboBox_Bend_Vert.Text;
                    string MM_GT = "MM GT";
                    string HEAT_GT = "HEAT GT";
                    string Wall_Thk_GT = "THK\r\n(IN) GT";
                    string Coating_GT = "COATING GT";
                    string Grade_GT = "GRADE GT";
                    string DWG_No = "DWG";
                    string Block_Name = "BLOCK";
                    string Block_Att = "ATTRIBUTE";
                    string Block_Values = "VALUES";


                    List<string> Prelim_FT_columns = new List<string>();
                    List<string> WM_columns = new List<string>();
                    List<string> GT_columns = new List<string>();
                    DT_Prelim = new System.Data.DataTable();



                    if (checkBox_Station.Checked == true)
                    {
                        DT_Prelim.Columns.Add(Station, typeof(double));
                        WM_columns.Add(comboBox_Station.Text);
                        Prelim_FT_columns.Add(Station);
                        GT_columns.Add("");
                    }

                    if (checkBox_Northing.Checked == true)
                    {

                        DT_Prelim.Columns.Add(Northing, typeof(double));
                        WM_columns.Add(comboBox_Northing.Text);
                        Prelim_FT_columns.Add(Northing);
                        GT_columns.Add("");
                    }

                    if (checkBox_Easting.Checked == true)
                    {

                        DT_Prelim.Columns.Add(Easting, typeof(double));
                        WM_columns.Add(comboBox_Easting.Text);
                        Prelim_FT_columns.Add(Easting);
                        GT_columns.Add("");
                    }

                    if (checkBox_Elevation.Checked == true)
                    {

                        DT_Prelim.Columns.Add(Elevation, typeof(double));
                        WM_columns.Add(comboBox_Elevation.Text);
                        Prelim_FT_columns.Add(Elevation);
                        GT_columns.Add("");
                    }

                    if (checkBox_Feature.Checked == true)
                    {

                        DT_Prelim.Columns.Add(Feature, typeof(string));
                        WM_columns.Add(comboBox_Feature_Code.Text);
                        Prelim_FT_columns.Add(Feature);
                        GT_columns.Add("");
                    }

                    if (checkBox_MM_Back.Checked == true)
                    {

                        DT_Prelim.Columns.Add(MM_Back, typeof(string));
                        WM_columns.Add(comboBox_MM_Back.Text);
                        Prelim_FT_columns.Add(MM_Back);
                        GT_columns.Add("");
                    }

                    if (checkBox_Description.Checked == true)
                    {

                        DT_Prelim.Columns.Add(Description, typeof(string));
                        WM_columns.Add(comboBox_Description.Text);
                        Prelim_FT_columns.Add(Description);
                        GT_columns.Add("");
                    }

                    if (checkBox_MM_Ahead.Checked == true)
                    {

                        DT_Prelim.Columns.Add(MM_Ahead, typeof(string));
                        WM_columns.Add(comboBox_MM_Ahead.Text);
                        Prelim_FT_columns.Add(MM_Ahead);
                        GT_columns.Add("");
                    }

                    if (checkBox_Heat_Back.Checked == true)
                    {

                        DT_Prelim.Columns.Add(Heat_Back, typeof(string));
                        WM_columns.Add(comboBox_Heat_Back.Text);
                        Prelim_FT_columns.Add(Heat_Back);
                        GT_columns.Add("");
                    }

                    if (checkBox_Heat_Ahead.Checked == true)
                    {

                        DT_Prelim.Columns.Add(Heat_Ahead, typeof(string));
                        WM_columns.Add(comboBox_Heat_Ahead.Text);
                        Prelim_FT_columns.Add(Heat_Ahead);
                        GT_columns.Add("");
                    }

                    //
                    DT_Prelim.Columns.Add(Prelim_Length, typeof(double));
                    WM_columns.Add(comboBox_Length.Text);
                    Prelim_FT_columns.Add(Prelim_Length);
                    GT_columns.Add("");
                    //

                    if (checkBox_GT_Pipe_DIA.Checked == true)
                    {

                        DT_Prelim.Columns.Add(Diameter, typeof(double));
                        WM_columns.Add("");
                        Prelim_FT_columns.Add(Diameter);
                        GT_columns.Add(comboBox_GT_Pipe_DIA.Text);

                    }

                    if (checkBox_Wall_Back.Checked == true)
                    {

                        DT_Prelim.Columns.Add(wall_back, typeof(double));
                        WM_columns.Add(comboBox_Wall_Back.Text);
                        Prelim_FT_columns.Add(wall_back);
                        GT_columns.Add("");
                    }

                    if (checkBox_Wall_Ahead.Checked == true)
                    {

                        DT_Prelim.Columns.Add(wall_ahead, typeof(double));
                        WM_columns.Add(comboBox_Wall_Ahead.Text);
                        Prelim_FT_columns.Add(wall_ahead);
                        GT_columns.Add("");
                    }

                    if (checkBox_Pipe_Back.Checked == true)
                    {

                        DT_Prelim.Columns.Add(pipe_back, typeof(string));
                        WM_columns.Add(comboBox_Pipe_Back.Text);
                        Prelim_FT_columns.Add(pipe_back);
                        GT_columns.Add("");
                    }

                    if (checkBox_Pipe_Ahead.Checked == true)
                    {

                        DT_Prelim.Columns.Add(pipe_ahead, typeof(string));
                        WM_columns.Add(comboBox_Pipe_Ahead.Text);
                        Prelim_FT_columns.Add(pipe_ahead);
                        GT_columns.Add("");
                    }

                    if (checkBox_Grade_Back.Checked == true)
                    {

                        DT_Prelim.Columns.Add(Grade_BK, typeof(string));
                        WM_columns.Add(comboBox_Grade_Back.Text);
                        Prelim_FT_columns.Add(Grade_BK);
                        GT_columns.Add("");
                    }

                    if (checkBox_Grade_Ahead.Checked == true)
                    {

                        DT_Prelim.Columns.Add(Grade_AHD, typeof(string));
                        WM_columns.Add(comboBox_Grade_Ahead.Text);
                        Prelim_FT_columns.Add(Grade_AHD);
                        GT_columns.Add("");
                    }

                    if (checkBox_Coating_Back.Checked == true)
                    {

                        DT_Prelim.Columns.Add(Coating_BK, typeof(string));
                        WM_columns.Add(comboBox_Coating_Back.Text);
                        Prelim_FT_columns.Add(Coating_BK);
                        GT_columns.Add("");
                    }

                    if (checkBox_Coating_Ahead.Checked == true)
                    {

                        DT_Prelim.Columns.Add(Coating_AHD, typeof(string));
                        WM_columns.Add(comboBox_Coating_Ahead.Text);
                        Prelim_FT_columns.Add(Coating_AHD);
                        GT_columns.Add("");
                    }

                    if (checkBox_NG_PNT.Checked == true)
                    {

                        DT_Prelim.Columns.Add(NG_PNT.ToUpper(), typeof(string));
                        WM_columns.Add(comboBox_NG_PNT.Text);
                        Prelim_FT_columns.Add(NG_PNT);
                        GT_columns.Add("");
                    }

                    if (checkBox_NG_Northing.Checked == true)
                    {

                        DT_Prelim.Columns.Add(NG_Northing, typeof(double));
                        WM_columns.Add(comboBox_NG_Northing.Text);
                        Prelim_FT_columns.Add(NG_Northing);
                        GT_columns.Add("");
                    }

                    if (checkBox_NG_Easting.Checked == true)
                    {

                        DT_Prelim.Columns.Add(NG_Easting, typeof(double));
                        WM_columns.Add(comboBox_NG_Easting.Text);
                        Prelim_FT_columns.Add(NG_Easting);
                        GT_columns.Add("");
                    }

                    if (checkBox_NG_Elevation.Checked == true)
                    {

                        DT_Prelim.Columns.Add(NG_Elevation, typeof(double));
                        WM_columns.Add(comboBox_NG_Elevation.Text);
                        Prelim_FT_columns.Add(NG_Elevation);
                        GT_columns.Add("");
                    }

                    if (checkBox_Cover.Checked == true)
                    {

                        DT_Prelim.Columns.Add(cover, typeof(double));
                        WM_columns.Add(comboBox_Cover.Text);
                        Prelim_FT_columns.Add(cover);
                        GT_columns.Add("");
                    }

                    if (checkBox_Location.Checked == true)
                    {

                        DT_Prelim.Columns.Add(location, typeof(string));
                        WM_columns.Add(comboBox_Location.Text);
                        Prelim_FT_columns.Add(location);
                        GT_columns.Add("");
                    }


                    if (checkBox_Bend_Horiz.Checked == true)
                    {

                        DT_Prelim.Columns.Add(Bend_Horiz, typeof(double));
                        WM_columns.Add(comboBox_Bend_Horiz.Text);
                        Prelim_FT_columns.Add(Bend_Horiz);
                        GT_columns.Add("");
                    }


                    if (checkBox_Bend_Vert.Checked == true)
                    {

                        DT_Prelim.Columns.Add(Bend_Vert, typeof(double));
                        WM_columns.Add(comboBox_Bend_Vert.Text);
                        Prelim_FT_columns.Add(Bend_Vert);
                        GT_columns.Add("");
                    }

                    if (checkBox_GT_MM.Checked == true)
                    {

                        DT_Prelim.Columns.Add(MM_GT, typeof(string));
                        WM_columns.Add("");
                        Prelim_FT_columns.Add(MM_GT);
                        GT_columns.Add(comboBox_GT_MM.Text);

                    }

                    if (checkBox_GT_Heat.Checked == true)
                    {

                        DT_Prelim.Columns.Add(HEAT_GT, typeof(string));
                        WM_columns.Add("");
                        Prelim_FT_columns.Add(HEAT_GT);
                        GT_columns.Add(comboBox_GT_Heat.Text);

                    }

                    if (checkBox_GT_Wall_Thk.Checked == true)
                    {

                        DT_Prelim.Columns.Add(Wall_Thk_GT, typeof(double));
                        WM_columns.Add("");
                        Prelim_FT_columns.Add(Wall_Thk_GT);
                        GT_columns.Add(comboBox_GT_Wall_Thk.Text);

                    }

                    if (checkBox_GT_Coating.Checked == true)
                    {

                        DT_Prelim.Columns.Add(Coating_GT, typeof(string));
                        WM_columns.Add("");
                        Prelim_FT_columns.Add(Coating_GT);
                        GT_columns.Add(comboBox_GT_Coating.Text);

                    }

                    if (checkBox_GT_Grade.Checked == true)
                    {
                        if (checkBox_Grade_Ahead.Checked == false)
                        {
                            Grade_GT = "GRADE";
                        }
                        DT_Prelim.Columns.Add(Grade_GT, typeof(string));
                        WM_columns.Add("");
                        Prelim_FT_columns.Add(Grade_GT);
                        GT_columns.Add(comboBox_GT_Grade.Text);

                    }

                    if (checkBox_PNT.Checked == true)
                    {
                        DT_Prelim.Columns.Add(PNT, typeof(string));
                        DT_Prelim.Columns[PNT].SetOrdinal(0);
                        WM_columns.Add(comboBox_PNT_WM.Text);
                        Prelim_FT_columns.Add(PNT);
                        GT_columns.Add("");
                    }

                    DT_Prelim.Columns.Add(DWG_No, typeof(string));
                    WM_columns.Add("");
                    Prelim_FT_columns.Add(DWG_No);
                    GT_columns.Add("");

                    DT_Prelim.Columns.Add(Block_Name, typeof(string));
                    WM_columns.Add("");
                    Prelim_FT_columns.Add(Block_Name);
                    GT_columns.Add("");

                    DT_Prelim.Columns.Add(Block_Att, typeof(string));
                    WM_columns.Add("");
                    Prelim_FT_columns.Add(Block_Att);
                    GT_columns.Add("");

                    DT_Prelim.Columns.Add(Block_Values, typeof(string));
                    WM_columns.Add("");
                    Prelim_FT_columns.Add(Block_Values);
                    GT_columns.Add("");

                    for (int i = 0; i < DT_Weld_Map.Rows.Count; ++i)
                    {

                        DT_Prelim.Rows.Add();
                        if (checkBox_PNT.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_PNT_WM.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_Station.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_Station.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_Northing.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_Northing.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_Easting.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_Easting.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_Elevation.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_Elevation.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_Feature.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_Feature_Code.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_MM_Back.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_MM_Back.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_Description.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_Description.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_MM_Ahead.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_MM_Ahead.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_Pipe_Back.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_Pipe_Back.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_Pipe_Ahead.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_Pipe_Ahead.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }


                        if (checkBox_Heat_Back.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_Heat_Back.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_Heat_Ahead.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_Heat_Ahead.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }


                        if (checkBox_Wall_Back.Checked == true)
                        {

                            int index1 = WM_columns.IndexOf(comboBox_Wall_Back.Text);

                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];
                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }


                        if (checkBox_Wall_Ahead.Checked == true)
                        {

                            int index1 = WM_columns.IndexOf(comboBox_Wall_Ahead.Text);

                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];
                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_Wall_Ahead.Checked == true)
                        {

                            int index1 = WM_columns.IndexOf(comboBox_Wall_Ahead.Text);

                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];
                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_Coating_Ahead.Checked == true)
                        {

                            int index1 = WM_columns.IndexOf(comboBox_Coating_Ahead.Text);

                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];
                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_Coating_Back.Checked == true)
                        {

                            int index1 = WM_columns.IndexOf(comboBox_Coating_Ahead.Text);

                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];
                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_Grade_Ahead.Checked == true)
                        {

                            int index1 = WM_columns.IndexOf(comboBox_Grade_Ahead.Text);

                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];
                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_Grade_Back.Checked == true)
                        {

                            int index1 = WM_columns.IndexOf(comboBox_Grade_Ahead.Text);

                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];
                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_Length.Checked == true)
                        {
                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][Prelim_Length] = DT_Weld_Map.Rows[i][comboBox_Length.Text];
                        }

                        else if (checkBox_Station.Checked == true && checkBox_Feature.Checked == true)
                        {
                            if (Convert.ToString(DT_Weld_Map.Rows[i][comboBox_Feature_Code.Text]) == "WELD")
                            {
                                DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][Prelim_Length] = Calc_Length(DT_Weld_Map, i);
                            }

                        }

                        if (checkBox_NG_PNT.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_NG_PNT.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_NG_Northing.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_NG_Northing.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_NG_Easting.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_NG_Easting.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_NG_Elevation.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_NG_Elevation.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_Cover.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_Cover.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = Math.Round((Convert.ToDouble(DT_Weld_Map.Rows[i][nameofcolumn2])), 2);
                        }

                        if (checkBox_Cover.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_Cover.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_Location.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_Location.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }

                        if (checkBox_Bend_Horiz.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_Bend_Horiz.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }


                        if (checkBox_Bend_Vert.Checked == true)
                        {
                            int index1 = WM_columns.IndexOf(comboBox_Bend_Vert.Text);
                            string nameofcolumn = Prelim_FT_columns[index1];
                            string nameofcolumn2 = WM_columns[index1];

                            DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Weld_Map.Rows[i][nameofcolumn2];
                        }


                        if (checkBox_GT_Pipe_DIA.Checked == true || checkBox_GT_MM.Checked == true || checkBox_GT_Heat.Checked == true
                            || checkBox_GT_Wall_Thk.Checked == true || checkBox_GT_Coating.Checked == true || checkBox_GT_Grade.Checked == true)
                        {
                            int index_for_row = -1;
                            string MM_Ahead_WM = Convert.ToString(DT_Weld_Map.Rows[i][comboBox_MM_Ahead.Text]);
                            for (int j = 0; j < DT_Ground_Tally.Rows.Count; ++j)
                            {
                                string MM_GT2 = Convert.ToString(DT_Ground_Tally.Rows[j][comboBox_GT_MM.Text]);
                                if (MM_GT2 == MM_Ahead_WM)
                                {
                                    index_for_row = j;
                                    j = DT_Ground_Tally.Rows.Count;
                                }
                            }

                            if (checkBox_GT_Pipe_DIA.Checked == true && index_for_row >= 0)
                            {
                                int index1 = GT_columns.IndexOf(comboBox_GT_Pipe_DIA.Text);
                                string nameofcolumn = Prelim_FT_columns[index1];
                                string nameofcolumn2 = GT_columns[index1];

                                DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Ground_Tally.Rows[index_for_row][nameofcolumn2];
                            }


                            if (checkBox_GT_MM.Checked == true && index_for_row >= 0)
                            {
                                int index1 = GT_columns.IndexOf(comboBox_GT_MM.Text);
                                string nameofcolumn = Prelim_FT_columns[index1];
                                string nameofcolumn2 = GT_columns[index1];

                                DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Ground_Tally.Rows[index_for_row][nameofcolumn2];
                            }

                            if (checkBox_GT_Heat.Checked == true && index_for_row >= 0)
                            {
                                int index1 = GT_columns.IndexOf(comboBox_GT_Heat.Text);
                                string nameofcolumn = Prelim_FT_columns[index1];
                                string nameofcolumn2 = GT_columns[index1];

                                DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Ground_Tally.Rows[index_for_row][nameofcolumn2];
                            }

                            if (checkBox_GT_Wall_Thk.Checked == true && index_for_row >= 0)
                            {
                                int index1 = GT_columns.IndexOf(comboBox_GT_Wall_Thk.Text);
                                string nameofcolumn = Prelim_FT_columns[index1];
                                string nameofcolumn2 = GT_columns[index1];

                                DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Ground_Tally.Rows[index_for_row][nameofcolumn2];
                            }

                            if (checkBox_GT_Coating.Checked == true && index_for_row >= 0)
                            {
                                int index1 = GT_columns.IndexOf(comboBox_GT_Coating.Text);
                                string nameofcolumn = Prelim_FT_columns[index1];
                                string nameofcolumn2 = GT_columns[index1];

                                DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Ground_Tally.Rows[index_for_row][nameofcolumn2];
                            }

                            if (checkBox_GT_Grade.Checked == true && index_for_row >= 0)
                            {
                                int index1 = GT_columns.IndexOf(comboBox_GT_Grade.Text);
                                string nameofcolumn = Prelim_FT_columns[index1];
                                string nameofcolumn2 = GT_columns[index1];

                                DT_Prelim.Rows[DT_Prelim.Rows.Count - 1][nameofcolumn] = DT_Ground_Tally.Rows[index_for_row][nameofcolumn2];
                            }

                        }

                    }

                    DT_Prelim.Columns.Add("INV STA", typeof(string));
                    DT_Prelim.Columns["INV STA"].SetOrdinal(1);
                    DT_Prelim.Columns[Station].SetOrdinal(DT_Prelim.Columns.Count - 1);

                    for (int i = 0; i < DT_Prelim.Rows.Count; ++i)
                    {
                        string desc = Convert.ToString(DT_Prelim.Rows[i]["DESCRIPTION"]);
                        double STA = Convert.ToDouble(DT_Prelim.Rows[i]["STA DBL"]);
                        string xray = Convert.ToString(DT_Prelim.Rows[i]["XRAY#"]);

                        string STA_String = Get_chainage_from_double(STA, "f", 0);
                        DT_Prelim.Rows[i]["INV STA"] = STA_String;

                        if (desc == "WELD")
                        {
                            DT_Prelim.Rows[i]["BLOCK"] = "Weld_Blk";
                            DT_Prelim.Rows[i]["ATTRIBUTE"] = "WELD_INFO";
                            DT_Prelim.Rows[i]["VALUES"] = STA_String + " " + xray;

                        }

                        if (desc == "CP_TEST_STATION")
                        {
                            DT_Prelim.Rows[i]["BLOCK"] = "TS_Blk";
                            DT_Prelim.Rows[i]["ATTRIBUTE"] = "TEST_STATION";
                            DT_Prelim.Rows[i]["VALUES"] = STA_String + " TEST STATION";

                        }

                        if (desc == "CENTERLINE_WATERWAY")
                        {
                            DT_Prelim.Rows[i]["BLOCK"] = "Stream_Labels";
                            DT_Prelim.Rows[i]["ATTRIBUTE"] = "CL_STREAM";
                            DT_Prelim.Rows[i]["VALUES"] = STA_String + " CL STREAM";

                        }

                        if (desc == "FOREIGN_PIPELINE")
                        {
                            DT_Prelim.Rows[i]["BLOCK"] = "Crossing_Labels";
                            DT_Prelim.Rows[i]["ATTRIBUTE"] = "CROSSING";
                            DT_Prelim.Rows[i]["VALUES"] = STA_String + " FOREIGN PIPELINE";
                        }

                        if (desc == "CENTERLINE_ROAD")
                        {
                            DT_Prelim.Rows[i]["BLOCK"] = "Road_Name_Blk";
                            DT_Prelim.Rows[i]["ATTRIBUTE"] = "ROAD_NAME";
                            DT_Prelim.Rows[i]["VALUES"] = xray;
                        }

                        //double sta1 = Convert.ToDouble(Convert.ToString(DT_Prelim.Rows[i]["INV STA"]).Replace("+","")); // use when you use INV STA
                    }

                    //DT_Prelim.Columns.Remove("STA DBL");
                    dataGridView_Prelim_Table.DataSource = DT_Prelim;
                    dataGridView_Prelim_Table.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                    dataGridView_Prelim_Table.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(37, 37, 38);
                    dataGridView_Prelim_Table.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                    dataGridView_Prelim_Table.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    Padding newpadding = new Padding(4, 0, 0, 0);
                    dataGridView_Prelim_Table.ColumnHeadersDefaultCellStyle.Padding = newpadding;
                    dataGridView_Prelim_Table.RowHeadersDefaultCellStyle.BackColor = Color.FromArgb(37, 37, 38);
                    dataGridView_Prelim_Table.DefaultCellStyle.BackColor = Color.FromArgb(51, 51, 55);
                    dataGridView_Prelim_Table.EnableHeadersVisualStyles = false;

                    DT_Filter = DT_Prelim.Copy();

                    if (DT_Filter.Columns.Contains(PNT))
                    {
                        DT_Filter.Columns.Remove(PNT);
                    }

                    if (DT_Filter.Columns.Contains(Station))
                    {
                        DT_Filter.Columns.Remove(Station);
                    }

                    if (DT_Filter.Columns.Contains("INV STA"))
                    {
                        DT_Filter.Columns.Remove("INV STA");
                    }

                    if (DT_Filter.Columns.Contains(Northing))
                    {
                        DT_Filter.Columns.Remove(Northing);
                    }

                    if (DT_Filter.Columns.Contains(Easting))
                    {
                        DT_Filter.Columns.Remove(Easting);
                    }

                    if (DT_Filter.Columns.Contains(Elevation))
                    {
                        DT_Filter.Columns.Remove(Elevation);
                    }

                    if (DT_Filter.Columns.Contains(Description))
                    {
                        DT_Filter.Columns.Remove(Description);
                    }

                    if (DT_Filter.Columns.Contains(MM_Back))
                    {
                        DT_Filter.Columns.Remove(MM_Back);
                    }

                    if (DT_Filter.Columns.Contains(MM_Ahead))
                    {
                        DT_Filter.Columns.Remove(MM_Ahead);
                    }

                    if (DT_Filter.Columns.Contains(wall_back))
                    {
                        DT_Filter.Columns.Remove(wall_back);
                    }

                    if (DT_Filter.Columns.Contains(wall_ahead))
                    {
                        DT_Filter.Columns.Remove(wall_ahead);
                    }

                    if (DT_Filter.Columns.Contains(pipe_back))
                    {
                        DT_Filter.Columns.Remove(pipe_back);
                    }

                    if (DT_Filter.Columns.Contains(pipe_ahead))
                    {
                        DT_Filter.Columns.Remove(pipe_ahead);
                    }

                    if (DT_Filter.Columns.Contains(Heat_Back))
                    {
                        DT_Filter.Columns.Remove(Heat_Back);
                    }

                    if (DT_Filter.Columns.Contains(Heat_Ahead))
                    {
                        DT_Filter.Columns.Remove(Heat_Ahead);
                    }

                    if (DT_Filter.Columns.Contains(Coating_BK))
                    {
                        DT_Filter.Columns.Remove(Coating_BK);
                    }

                    if (DT_Filter.Columns.Contains(Coating_AHD))
                    {
                        DT_Filter.Columns.Remove(Coating_AHD);
                    }

                    if (DT_Filter.Columns.Contains(Grade_BK))
                    {
                        DT_Filter.Columns.Remove(Grade_BK);
                    }

                    if (DT_Filter.Columns.Contains(Grade_AHD))
                    {
                        DT_Filter.Columns.Remove(Grade_AHD);
                    }

                    if (DT_Filter.Columns.Contains(Prelim_Length))
                    {
                        DT_Filter.Columns.Remove(Prelim_Length);
                    }

                    if (DT_Filter.Columns.Contains(NG_PNT))
                    {
                        DT_Filter.Columns.Remove(NG_PNT);
                    }

                    if (DT_Filter.Columns.Contains(NG_Northing))
                    {
                        DT_Filter.Columns.Remove(NG_Northing);
                    }

                    if (DT_Filter.Columns.Contains(NG_Easting))
                    {
                        DT_Filter.Columns.Remove(NG_Easting);
                    }

                    if (DT_Filter.Columns.Contains(NG_Elevation))
                    {
                        DT_Filter.Columns.Remove(NG_Elevation);
                    }

                    if (DT_Filter.Columns.Contains(cover))
                    {
                        DT_Filter.Columns.Remove(cover);
                    }

                    if (DT_Filter.Columns.Contains(location))
                    {
                        DT_Filter.Columns.Remove(location);
                    }

                    if (DT_Filter.Columns.Contains(Bend_Horiz))
                    {
                        DT_Filter.Columns.Remove(Bend_Horiz);
                    }

                    if (DT_Filter.Columns.Contains(Bend_Vert))
                    {
                        DT_Filter.Columns.Remove(Bend_Vert);
                    }

                    if (DT_Filter.Columns.Contains(MM_GT))
                    {
                        DT_Filter.Columns.Remove(MM_GT);
                    }

                    if (DT_Filter.Columns.Contains(HEAT_GT))
                    {
                        DT_Filter.Columns.Remove(HEAT_GT);
                    }

                    if (DT_Filter.Columns.Contains(Wall_Thk_GT))
                    {
                        DT_Filter.Columns.Remove(Wall_Thk_GT);
                    }

                    if (DT_Filter.Columns.Contains(Diameter))
                    {
                        DT_Filter.Columns.Remove(Diameter);
                    }

                    if (DT_Filter.Columns.Contains(Coating_GT))
                    {
                        DT_Filter.Columns.Remove(Coating_GT);
                    }

                    if (DT_Filter.Columns.Contains(Grade_GT))
                    {
                        DT_Filter.Columns.Remove(Grade_GT);
                    }

                    if (DT_Filter.Columns.Contains(DWG_No))
                    {
                        DT_Filter.Columns.Remove(DWG_No);
                    }


                    if (DT_Filter.Columns.Contains(Block_Name))
                    {
                        DT_Filter.Columns.Remove(Block_Name);
                    }

                    if (DT_Filter.Columns.Contains(Block_Att))
                    {
                        DT_Filter.Columns.Remove(Block_Att);
                    }

                    if (DT_Filter.Columns.Contains(Block_Values))
                    {
                        DT_Filter.Columns.Remove(Block_Values);
                    }

                    DT_Filter.Columns.Add("USE", typeof(Boolean));
                    DT_Filter.Columns.Add("ALIAS", typeof(String));
                    DT_Filter.Columns["USE"].SetOrdinal(0);
                    DT_Filter.Columns["DESCRIPTION"].SetOrdinal(1);
                    DT_Filter.Columns["ALIAS"].SetOrdinal(2);

                    System.Data.DataTable DT_Filter2 = DT_Filter.DefaultView.ToTable( /*distinct*/ true);
                    DT_Filter = DT_Filter2.Copy();

                    for (int i = 0; i < DT_Filter.Rows.Count; ++i)
                    {
                        string txt_read = Convert.ToString(DT_Filter.Rows[i][1]);

                        DT_Filter.Rows[i][0] = false;
                        DT_Filter.Rows[i][2] = "REMOVE";

                        if (txt_read == "CP_CAD_WELD")
                        {
                            DT_Filter.Rows[i][0] = true;
                            DT_Filter.Rows[i][2] = "CAD WELD";
                        }

                        if (txt_read == "WELD")
                        {
                            DT_Filter.Rows[i][0] = true;
                            DT_Filter.Rows[i][2] = "WELD";
                        }

                        if (txt_read == "BEND")
                        {
                            DT_Filter.Rows[i][0] = true;
                            DT_Filter.Rows[i][2] = "CAN'T CHANGE";
                        }

                        if (txt_read == "DITCH")
                        {
                            DT_Filter.Rows[i][0] = true;
                            DT_Filter.Rows[i][2] = "CL DITCH";
                        }

                        if (txt_read == "TRENCH_BREAKERS")
                        {
                            DT_Filter.Rows[i][0] = true;
                            DT_Filter.Rows[i][2] = "TRENCH PLUG";
                        }

                        if (txt_read == "CENTERLINE_ROAD")
                        {
                            DT_Filter.Rows[i][0] = true;
                            DT_Filter.Rows[i][2] = "CL ROAD";
                        }

                        if (txt_read == "CENTERLINE_WATERWAY")
                        {
                            DT_Filter.Rows[i][0] = true;
                            DT_Filter.Rows[i][2] = "CL STREAM";
                        }

                        if (txt_read == "CP_TEST_STATION")
                        {
                            DT_Filter.Rows[i][0] = true;
                            DT_Filter.Rows[i][2] = "TEST STATION";
                        }

                        if (txt_read == "FOREIGN_PIPELINE")
                        {
                            DT_Filter.Rows[i][0] = true;
                            DT_Filter.Rows[i][2] = "FOREIGN PIPELINE";
                        }

                        if (txt_read == "UTILITY")
                        {
                            DT_Filter.Rows[i][0] = true;
                            DT_Filter.Rows[i][2] = "CAN'T CHANGE";
                        }

                    }

                    dataGridView_Filter.DataSource = DT_Filter;
                    //dataGridView_Filter.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                    dataGridView_Filter.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(37, 37, 38);
                    dataGridView_Filter.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                    dataGridView_Filter.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    newpadding = new Padding(4, 0, 0, 0);
                    dataGridView_Filter.Columns[0].Width = 40;
                    dataGridView_Filter.Columns[1].Width = 129;
                    dataGridView_Filter.Columns[2].Width = 129;
                    dataGridView_Filter.ColumnHeadersDefaultCellStyle.Padding = newpadding;
                    dataGridView_Filter.RowHeadersWidth = 20;
                    dataGridView_Filter.RowHeadersDefaultCellStyle.BackColor = Color.FromArgb(37, 37, 38);
                    dataGridView_Filter.DefaultCellStyle.BackColor = Color.FromArgb(51, 51, 55);
                    dataGridView_Filter.EnableHeadersVisualStyles = false;
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                freezeoperation = false;

            }
        }

        private void button_Filter_Click(object sender, EventArgs e)
        {
            if (dataGridView_Filter.Visible == false)
            {
                dataGridView_Filter.Visible = true;
                return;
            }

            if (dataGridView_Filter.Visible == true)
            {
                dataGridView_Filter.Visible = false;
                return;
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Transfer_datatable_to_new_excel_spreadsheet(DT_Filter);
        }

        private void button4_Finalize_Click(object sender, EventArgs e)
        {
            if (freezeoperation == false)
            {
                freezeoperation = true;
                try
                {
                    DT_Final = DT_Prelim.Copy();

                    DataSet dataset1 = new DataSet();
                    dataset1.Tables.Add(DT_Final);
                    dataset1.Tables.Add(DT_Filter);

                    DataRelation relation1 = new DataRelation("xxx", DT_Final.Columns["DESCRIPTION"], DT_Filter.Columns["DESCRIPTION"], false);
                    dataset1.Relations.Add(relation1);

                    for (int i = DT_Final.Rows.Count - 1; i >= 0; --i)
                    {
                        if (DT_Final.Rows[i].GetChildRows(relation1).Length > 0)
                        {
                            if ((bool)DT_Final.Rows[i].GetChildRows(relation1)[0][0] == false)
                            {
                                DT_Final.Rows[i].Delete();

                            }
                            else
                            {
                                string exist_desc = Convert.ToString(DT_Final.Rows[i]["DESCRIPTION"]);
                                if (exist_desc.ToUpper() == "BEND" || exist_desc.ToUpper() == "UTILITY")
                                {
                                    string new_desc = "";

                                    if (checkBox_Description.Checked == true && DT_Final.Rows[i]["XRAY#"] != DBNull.Value)
                                    {
                                        string XRAY_desc = Convert.ToString(DT_Final.Rows[i]["XRAY#"]);


                                        DT_Final.Rows[i]["XRAY#"] = DBNull.Value;


                                        if (XRAY_desc.Contains("RIGHT"))
                                        {
                                            int index1 = XRAY_desc.IndexOf("RIGHT");
                                            int index2 = XRAY_desc.IndexOf("/", index1);
                                            int index3 = XRAY_desc.IndexOf("/", index2 + 1);
                                            int length4 = XRAY_desc.Length - index3 - 2;
                                            if (length4 == 0)
                                            {
                                                length4 = 1;
                                            }
                                            new_desc = XRAY_desc.Substring(index3 + 1, length4) + " RT";


                                            string STA = Convert.ToString(DT_Final.Rows[i]["INV STA"]);


                                            DT_Final.Rows[i]["BLOCK"] = "Bend_Blk";
                                            DT_Final.Rows[i]["ATTRIBUTE"] = "BEND_INFO";
                                            DT_Final.Rows[i]["VALUES"] = STA + " " + new_desc;
                                        }

                                        if (XRAY_desc.Contains("LEFT"))
                                        {
                                            int index1 = XRAY_desc.IndexOf("LEFT");
                                            int index2 = XRAY_desc.IndexOf("/", index1);
                                            int index3 = XRAY_desc.IndexOf("/", index2 + 1);
                                            int length4 = XRAY_desc.Length - index3 - 2;
                                            if (length4 == 0)
                                            {
                                                length4 = 1;
                                            }
                                            new_desc = XRAY_desc.Substring(index3 + 1, length4) + " LT";


                                            string STA = Convert.ToString(DT_Final.Rows[i]["INV STA"]);


                                            DT_Final.Rows[i]["BLOCK"] = "Bend_Blk";
                                            DT_Final.Rows[i]["ATTRIBUTE"] = "BEND_INFO";
                                            DT_Final.Rows[i]["VALUES"] = STA + " " + new_desc;
                                        }

                                        if (XRAY_desc.Contains("OVERBEND"))
                                        {
                                            int index1 = XRAY_desc.IndexOf("OVERBEND");
                                            int index2 = XRAY_desc.IndexOf("/", index1);
                                            int index3 = XRAY_desc.IndexOf("/", index2 + 1);
                                            int length4 = XRAY_desc.Length - index3 - 2;
                                            if (length4 == 0)
                                            {
                                                length4 = 1;
                                            }
                                            new_desc = XRAY_desc.Substring(index3 + 1, length4) + " OB";


                                            string STA = Convert.ToString(DT_Final.Rows[i]["INV STA"]);


                                            DT_Final.Rows[i]["BLOCK"] = "Bend_Blk";
                                            DT_Final.Rows[i]["ATTRIBUTE"] = "BEND_INFO";
                                            DT_Final.Rows[i]["VALUES"] = STA + " " + new_desc;
                                        }

                                        if (XRAY_desc.Contains("SAG"))
                                        {
                                            int index1 = XRAY_desc.IndexOf("SAG");
                                            int index2 = XRAY_desc.IndexOf("/", index1);
                                            int index3 = XRAY_desc.IndexOf("/", index2 + 1);
                                            int length4 = XRAY_desc.Length - index3 - 2;
                                            if (length4 == 0)
                                            {
                                                length4 = 1;
                                            }
                                            new_desc = XRAY_desc.Substring(index3 + 1, length4) + " SAG";

                                            string STA = Convert.ToString(DT_Final.Rows[i]["INV STA"]);


                                            DT_Final.Rows[i]["BLOCK"] = "Bend_Blk";
                                            DT_Final.Rows[i]["ATTRIBUTE"] = "BEND_INFO";
                                            DT_Final.Rows[i]["VALUES"] = STA + " " + new_desc;
                                        }


                                        if (XRAY_desc.Contains("STORM SEWER"))
                                        {

                                            new_desc = "SEWER LINE";

                                            string STA = Convert.ToString(DT_Final.Rows[i]["INV STA"]);
                                            DT_Final.Rows[i]["BLOCK"] = "Crossing_Labels";
                                            DT_Final.Rows[i]["ATTRIBUTE"] = "CROSSING";
                                            DT_Final.Rows[i]["VALUES"] = STA + " " + new_desc;
                                        }

                                        if (XRAY_desc.Contains("WATER"))
                                        {
                                            new_desc = "WATER LINE";


                                            string STA = Convert.ToString(DT_Final.Rows[i]["INV STA"]);
                                            DT_Final.Rows[i]["BLOCK"] = "Crossing_Labels";
                                            DT_Final.Rows[i]["ATTRIBUTE"] = "CROSSING";
                                            DT_Final.Rows[i]["VALUES"] = STA + " " + new_desc;
                                        }

                                        if (XRAY_desc.Contains("GAS"))
                                        {
                                            new_desc = "GAS LINE";


                                            string STA = Convert.ToString(DT_Final.Rows[i]["INV STA"]);
                                            DT_Final.Rows[i]["BLOCK"] = "Crossing_Labels";
                                            DT_Final.Rows[i]["ATTRIBUTE"] = "CROSSING";
                                            DT_Final.Rows[i]["VALUES"] = STA + " " + new_desc;
                                        }

                                        if (XRAY_desc.Contains("OVERHEAD POWER"))
                                        {
                                            new_desc = "OVERHEAD POWER LINE";


                                            string STA = Convert.ToString(DT_Final.Rows[i]["INV STA"]);
                                            DT_Final.Rows[i]["BLOCK"] = "Crossing_Labels";
                                            DT_Final.Rows[i]["ATTRIBUTE"] = "CROSSING";
                                            DT_Final.Rows[i]["VALUES"] = STA + " " + new_desc;
                                        }

                                        if (XRAY_desc.Contains("POWER"))
                                        {
                                            new_desc = "UNDERGROUND POWER";


                                            string STA = Convert.ToString(DT_Final.Rows[i]["INV STA"]);
                                            DT_Final.Rows[i]["BLOCK"] = "Crossing_Labels";
                                            DT_Final.Rows[i]["ATTRIBUTE"] = "CROSSING";
                                            DT_Final.Rows[i]["VALUES"] = STA + " " + new_desc;
                                        }

                                        if (XRAY_desc.Contains("(SEE NOTES)"))
                                        {
                                            new_desc = "(SEE NOTES)";


                                            string STA = Convert.ToString(DT_Final.Rows[i]["INV STA"]);
                                            DT_Final.Rows[i]["BLOCK"] = "Crossing_Labels";
                                            DT_Final.Rows[i]["ATTRIBUTE"] = "CROSSING";
                                            DT_Final.Rows[i]["VALUES"] = STA + " " + new_desc;
                                        }

                                        if (XRAY_desc.Contains("TELEPHONE"))
                                        {
                                            new_desc = "TELEPHONE LINE";


                                            string STA = Convert.ToString(DT_Final.Rows[i]["INV STA"]);
                                            DT_Final.Rows[i]["BLOCK"] = "Crossing_Labels";
                                            DT_Final.Rows[i]["ATTRIBUTE"] = "CROSSING";
                                            DT_Final.Rows[i]["VALUES"] = STA + " " + new_desc;
                                        }

                                    }

                                    DT_Final.Rows[i]["DESCRIPTION"] = new_desc;
                                }

                                else
                                {
                                    DT_Final.Rows[i]["DESCRIPTION"] = Convert.ToString(DT_Final.Rows[i].GetChildRows(relation1)[0][2]);
                                }

                                if (exist_desc.ToUpper() == "TRENCH_BREAKERS" || exist_desc.ToUpper() == "CP_CAD_WELD" || exist_desc.ToUpper() == "CENTERLINE_ROAD" ||
                                    exist_desc.ToUpper() == "CENTERLINE_WATERWAY" || exist_desc.ToUpper() == "CP_TEST_STATION" || exist_desc.ToUpper() == "FOREIGN_PIPELINE")
                                {

                                    if (checkBox_Description.Checked == true && DT_Final.Rows[i]["XRAY#"] != DBNull.Value)
                                    {
                                        DT_Final.Rows[i]["XRAY#"] = DBNull.Value;
                                    }
                                }

                                if (exist_desc.ToUpper() == "UTILITY")
                                {

                                    if (checkBox_Description.Checked == true && DT_Final.Rows[i]["XRAY#"] != DBNull.Value)
                                    {
                                        string ex_desc = Convert.ToString(DT_Final.Rows[i]["XRAY#"]);

                                        DT_Final.Rows[i]["XRAY#"] = DBNull.Value;

                                        if (exist_desc.Contains("STORM SEWER"))
                                        {

                                        }
                                    }
                                }

                            }

                        }
                    }
                    dataset1.Relations.Remove(relation1);
                    dataset1.Tables.Remove(DT_Final);
                    dataset1.Tables.Remove(DT_Filter);







                    dataGridView_Prelim_Table.DataSource = DT_Final;
                    dataGridView_Prelim_Table.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                }

                catch (System.Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                freezeoperation = false;
            }
        }
        private void set_row_height(Microsoft.Office.Interop.Excel.Worksheet w1, int row, double row_height)
        {

            w1.Rows[row].RowHeight = row_height;

        }

        private void set_column_width(Microsoft.Office.Interop.Excel.Worksheet w1, string column, int column_width)
        {

            w1.Columns[column].ColumnWidth = column_width;

        }

        private void Color_border_range(Microsoft.Office.Interop.Excel.Range range1)
        {
            //private void Color_border_range(Microsoft.Office.Interop.Excel.Range range1, int color, int color_index, int theme_color, double tint_n_shade, int font_color)
            range1.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeTop].LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
            range1.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeTop].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
            range1.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
            range1.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeBottom].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
            range1.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
            range1.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeLeft].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
            range1.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeRight].LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
            range1.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeRight].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
            range1.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlInsideHorizontal].LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
            range1.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlInsideVertical].LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
            //range1.Interior.Pattern = Microsoft.Office.Interop.Excel.XlPattern.xlPatternNone;
            range1.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
            range1.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;

        }
        public void Transfer_datatable_to_new_excel_spreadsheet_Formatting(System.Data.DataTable dt1)
        {
            if (freezeoperation == false)
            {
                freezeoperation = true;
                try
                {
                    if (dt1 != null)
                    {
                        if (dt1.Rows.Count > 0)
                        {
                            Microsoft.Office.Interop.Excel.Worksheet W1 = Get_NEW_worksheet_from_Excel();
                            W1.Cells.NumberFormat = "@";
                            int maxRows = dt1.Rows.Count;
                            int maxCols = dt1.Columns.Count;
                            Microsoft.Office.Interop.Excel.Range range1 = W1.Range[W1.Cells[2, 1], W1.Cells[maxRows + 1, maxCols]];
                            object[,] values1 = new object[maxRows, maxCols];

                            for (int i = 0; i < maxRows; ++i)
                            {
                                for (int j = 0; j < maxCols; ++j)
                                {
                                    if (dt1.Rows[i][j] != DBNull.Value)
                                    {
                                        values1[i, j] = dt1.Rows[i][j];
                                    }
                                }
                            }

                            for (int i = 0; i < dt1.Columns.Count; ++i)
                            {
                                W1.Cells[1, i + 1].value2 = dt1.Columns[i].ColumnName;
                            }
                            range1.Value2 = values1;
                        }
                    }
                }


                catch (System.Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                freezeoperation = false;
            }
        }
        public void Feature_Table_Formatted(System.Data.DataTable dt1)
        {
            if (dt1 != null)
            {
                if (dt1.Rows.Count > 0)
                {
                    Worksheet W3 = Get_NEW_worksheet_from_Excel();
                    W3.Cells.NumberFormat = "General";
                    int maxRows = dt1.Rows.Count;
                    int maxCols = dt1.Columns.Count;
                    Microsoft.Office.Interop.Excel.Range range1 = W3.Range[W3.Cells[2, 1], W3.Cells[maxRows + 1, maxCols]];
                    object[,] values1 = new object[maxRows, maxCols];

                    for (int i = 0; i < maxRows; ++i)
                    {
                        for (int j = 0; j < maxCols; ++j)
                        {
                            if (dt1.Rows[i][j] != DBNull.Value)
                            {
                                values1[i, j] = dt1.Rows[i][j];
                            }
                        }
                    }

                    for (int i = 0; i < dt1.Columns.Count; ++i)
                    {
                        W3.Cells[1, i + 1].value2 = dt1.Columns[i].ColumnName;
                    }
                    range1.Value2 = values1;

                    int end_column = dt1.Columns.Count;
                    int end_row = dt1.Rows.Count;

                    Microsoft.Office.Interop.Excel.Range range3 = W3.Range[W3.Cells[1, 1], W3.Cells[end_row + 1, end_column]];
                    Color_border_range(range3);

                    for (int i = 0; i < dt1.Rows.Count; ++i)
                    {

                        if ((dt1.Columns.Contains("DESCRIPTION")))
                        {
                            string desc = Convert.ToString(dt1.Rows[i]["DESCRIPTION"]);
                            string block = Convert.ToString(dt1.Rows[i]["BLOCK"]);

                            if (desc == "CAD WELD")
                            {
                                Microsoft.Office.Interop.Excel.Range range2 = W3.Range[W3.Cells[i + 2, 1], W3.Cells[i + 2, end_column]];
                                range2.Interior.Color = 6802331;
                            }

                            if (block == "Weld_Blk")
                            {
                                Microsoft.Office.Interop.Excel.Range range2 = W3.Range[W3.Cells[i + 2, 1], W3.Cells[i + 2, end_column]];
                                range2.Interior.Color = 14145495;
                            }

                            if (block == "Bend_Blk")
                            {
                                Microsoft.Office.Interop.Excel.Range range2 = W3.Range[W3.Cells[i + 2, 1], W3.Cells[i + 2, end_column]];
                                range2.Interior.Color = 16764415;
                            }

                            if (block == "TS_Blk")
                            {
                                Microsoft.Office.Interop.Excel.Range range2 = W3.Range[W3.Cells[i + 2, 1], W3.Cells[i + 2, end_column]];
                                range2.Interior.Color = 12896255;
                            }


                            if (block == "Crossing_Labels")
                            {
                                Microsoft.Office.Interop.Excel.Range range2 = W3.Range[W3.Cells[i + 2, 1], W3.Cells[i + 2, end_column]];
                                range2.Interior.Color = 10092286;
                            }
                        }

                    }


                        set_column_width(W3, "PNT", 100);
                    
                }
            }
        }
        private void button_Export_Click(object sender, EventArgs e)
        {
            Feature_Table_Formatted(DT_Final);
        }

        private void button_Sheet_Index_Click(object sender, EventArgs e)
        {
            if (panel_Sheet_Index.Visible == true)

            {
                panel_Sheet_Index.Visible = false;
            }

            else
            {
                panel_Sheet_Index.Visible = true;
            }
        }
    }
}
