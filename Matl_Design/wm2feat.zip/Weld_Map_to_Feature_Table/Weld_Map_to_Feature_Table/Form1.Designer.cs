﻿namespace Weld_Map_to_Feature_Table
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel_header = new System.Windows.Forms.Panel();
            this.button_minimize = new System.Windows.Forms.Button();
            this.button_Exit = new System.Windows.Forms.Button();
            this.label_mm = new System.Windows.Forms.Label();
            this.panel_Data_Check = new System.Windows.Forms.Panel();
            this.panel_Sheet_Index = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.button_Scan_Sheet_Index = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.dataGridView_Filter = new System.Windows.Forms.DataGridView();
            this.dataGridView_Prelim_Table = new System.Windows.Forms.DataGridView();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button_Sheet_Index = new System.Windows.Forms.Button();
            this.button_Export = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4_Finalize = new System.Windows.Forms.Button();
            this.button_Filter = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.button_Prelim_Feature_Table = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox_sht_2 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.button_Scan_Ground_Tally = new System.Windows.Forms.Button();
            this.textBox_GT_Start_Column = new System.Windows.Forms.TextBox();
            this.textBox_GT_End_Row = new System.Windows.Forms.TextBox();
            this.textBox_GT_Start_Row = new System.Windows.Forms.TextBox();
            this.textBox_GT_End_Column = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.checkBox_GT_Heat = new System.Windows.Forms.CheckBox();
            this.textBox_color_check = new System.Windows.Forms.TextBox();
            this.checkBox_GT_Coating = new System.Windows.Forms.CheckBox();
            this.checkBox_GT_Grade = new System.Windows.Forms.CheckBox();
            this.checkBox_GT_Pipe_DIA = new System.Windows.Forms.CheckBox();
            this.checkBox_GT_Wall_Thk = new System.Windows.Forms.CheckBox();
            this.button6 = new System.Windows.Forms.Button();
            this.checkBox_GT_MM = new System.Windows.Forms.CheckBox();
            this.comboBox_GT_MM = new System.Windows.Forms.ComboBox();
            this.comboBox_GT_Wall_Thk = new System.Windows.Forms.ComboBox();
            this.comboBox_GT_Heat = new System.Windows.Forms.ComboBox();
            this.comboBox_GT_Grade = new System.Windows.Forms.ComboBox();
            this.comboBox_GT_Pipe_DIA = new System.Windows.Forms.ComboBox();
            this.comboBox_GT_Coating = new System.Windows.Forms.ComboBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.comboBox_Length = new System.Windows.Forms.ComboBox();
            this.checkBox_Length = new System.Windows.Forms.CheckBox();
            this.checkBox_Bend_Vert = new System.Windows.Forms.CheckBox();
            this.checkBox_Bend_Horiz = new System.Windows.Forms.CheckBox();
            this.comboBox_Location = new System.Windows.Forms.ComboBox();
            this.comboBox_Cover = new System.Windows.Forms.ComboBox();
            this.comboBox_Bend_Vert = new System.Windows.Forms.ComboBox();
            this.checkBox_Location = new System.Windows.Forms.CheckBox();
            this.comboBox_NG_Elevation = new System.Windows.Forms.ComboBox();
            this.comboBox_Bend_Horiz = new System.Windows.Forms.ComboBox();
            this.comboBox_NG_Easting = new System.Windows.Forms.ComboBox();
            this.comboBox_NG_Northing = new System.Windows.Forms.ComboBox();
            this.checkBox_Cover = new System.Windows.Forms.CheckBox();
            this.comboBox_NG_PNT = new System.Windows.Forms.ComboBox();
            this.checkBox_NG_Elevation = new System.Windows.Forms.CheckBox();
            this.comboBox_Grade_Back = new System.Windows.Forms.ComboBox();
            this.comboBox_Grade_Ahead = new System.Windows.Forms.ComboBox();
            this.checkBox_NG_Easting = new System.Windows.Forms.CheckBox();
            this.checkBox_Grade_Ahead = new System.Windows.Forms.CheckBox();
            this.checkBox_Grade_Back = new System.Windows.Forms.CheckBox();
            this.checkBox_NG_Northing = new System.Windows.Forms.CheckBox();
            this.label40 = new System.Windows.Forms.Label();
            this.checkBox_Coating_Ahead = new System.Windows.Forms.CheckBox();
            this.checkBox_Coating_Back = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.checkBox_NG_PNT = new System.Windows.Forms.CheckBox();
            this.checkBox_Heat_Ahead = new System.Windows.Forms.CheckBox();
            this.label18 = new System.Windows.Forms.Label();
            this.checkBox_Heat_Back = new System.Windows.Forms.CheckBox();
            this.checkBox_Pipe_Ahead = new System.Windows.Forms.CheckBox();
            this.checkBox_Pipe_Back = new System.Windows.Forms.CheckBox();
            this.comboBox_MM_Back = new System.Windows.Forms.ComboBox();
            this.comboBox_MM_Ahead = new System.Windows.Forms.ComboBox();
            this.checkBox_Wall_Ahead = new System.Windows.Forms.CheckBox();
            this.checkBox_Wall_Back = new System.Windows.Forms.CheckBox();
            this.comboBox_Wall_Back = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.checkBox_MM_Ahead = new System.Windows.Forms.CheckBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox_Coating_Back = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox_Pipe_Back = new System.Windows.Forms.ComboBox();
            this.comboBox_Coating_Ahead = new System.Windows.Forms.ComboBox();
            this.comboBox_Heat_Back = new System.Windows.Forms.ComboBox();
            this.comboBox_Wall_Ahead = new System.Windows.Forms.ComboBox();
            this.comboBox_Heat_Ahead = new System.Windows.Forms.ComboBox();
            this.comboBox_Description = new System.Windows.Forms.ComboBox();
            this.comboBox_Pipe_Ahead = new System.Windows.Forms.ComboBox();
            this.comboBox_PNT_WM = new System.Windows.Forms.ComboBox();
            this.comboBox_Northing = new System.Windows.Forms.ComboBox();
            this.checkBox_PNT = new System.Windows.Forms.CheckBox();
            this.checkBox_MM_Back = new System.Windows.Forms.CheckBox();
            this.comboBox_Feature_Code = new System.Windows.Forms.ComboBox();
            this.checkBox_Northing = new System.Windows.Forms.CheckBox();
            this.comboBox_Easting = new System.Windows.Forms.ComboBox();
            this.checkBox_Station = new System.Windows.Forms.CheckBox();
            this.comboBox_Station = new System.Windows.Forms.ComboBox();
            this.comboBox_Elevation = new System.Windows.Forms.ComboBox();
            this.checkBox_Description = new System.Windows.Forms.CheckBox();
            this.checkBox_Feature = new System.Windows.Forms.CheckBox();
            this.checkBox_Elevation = new System.Windows.Forms.CheckBox();
            this.checkBox_Easting = new System.Windows.Forms.CheckBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox_sht_1 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button_Scan_Weld_Map = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_WM_Start_Column = new System.Windows.Forms.TextBox();
            this.textBox_WM_End_Column = new System.Windows.Forms.TextBox();
            this.textBox_WM_Start_Row = new System.Windows.Forms.TextBox();
            this.textBox_WM_End_Row = new System.Windows.Forms.TextBox();
            this.panel_header.SuspendLayout();
            this.panel_Data_Check.SuspendLayout();
            this.panel_Sheet_Index.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Filter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Prelim_Table)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_header
            // 
            this.panel_header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.panel_header.Controls.Add(this.button_minimize);
            this.panel_header.Controls.Add(this.button_Exit);
            this.panel_header.Controls.Add(this.label_mm);
            this.panel_header.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_header.Location = new System.Drawing.Point(0, 0);
            this.panel_header.Name = "panel_header";
            this.panel_header.Size = new System.Drawing.Size(1405, 39);
            this.panel_header.TabIndex = 2107;
            this.panel_header.MouseDown += new System.Windows.Forms.MouseEventHandler(this.clickmove_MouseDown);
            this.panel_header.MouseMove += new System.Windows.Forms.MouseEventHandler(this.clickmove_MouseMove);
            this.panel_header.MouseUp += new System.Windows.Forms.MouseEventHandler(this.clickmove_MouseUp);
            // 
            // button_minimize
            // 
            this.button_minimize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.button_minimize.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_minimize.BackgroundImage")));
            this.button_minimize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_minimize.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.button_minimize.FlatAppearance.BorderSize = 0;
            this.button_minimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button_minimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button_minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_minimize.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_minimize.ForeColor = System.Drawing.Color.White;
            this.button_minimize.Location = new System.Drawing.Point(1336, 4);
            this.button_minimize.Name = "button_minimize";
            this.button_minimize.Size = new System.Drawing.Size(30, 30);
            this.button_minimize.TabIndex = 162;
            this.button_minimize.UseVisualStyleBackColor = false;
            this.button_minimize.Click += new System.EventHandler(this.button_minimize_Click);
            // 
            // button_Exit
            // 
            this.button_Exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.button_Exit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_Exit.BackgroundImage")));
            this.button_Exit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_Exit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.button_Exit.FlatAppearance.BorderSize = 0;
            this.button_Exit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button_Exit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Exit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Exit.ForeColor = System.Drawing.Color.White;
            this.button_Exit.Location = new System.Drawing.Point(1372, 4);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(30, 30);
            this.button_Exit.TabIndex = 161;
            this.button_Exit.UseVisualStyleBackColor = false;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // label_mm
            // 
            this.label_mm.AutoSize = true;
            this.label_mm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_mm.ForeColor = System.Drawing.Color.White;
            this.label_mm.Location = new System.Drawing.Point(3, 9);
            this.label_mm.Name = "label_mm";
            this.label_mm.Size = new System.Drawing.Size(137, 20);
            this.label_mm.TabIndex = 3;
            this.label_mm.Text = "Mott Macdonald";
            // 
            // panel_Data_Check
            // 
            this.panel_Data_Check.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.panel_Data_Check.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_Data_Check.Controls.Add(this.panel_Sheet_Index);
            this.panel_Data_Check.Controls.Add(this.dataGridView_Filter);
            this.panel_Data_Check.Controls.Add(this.dataGridView_Prelim_Table);
            this.panel_Data_Check.Controls.Add(this.panel5);
            this.panel_Data_Check.Controls.Add(this.panel2);
            this.panel_Data_Check.Controls.Add(this.panel3);
            this.panel_Data_Check.Controls.Add(this.panel10);
            this.panel_Data_Check.Controls.Add(this.panel9);
            this.panel_Data_Check.Controls.Add(this.panel8);
            this.panel_Data_Check.Controls.Add(this.panel7);
            this.panel_Data_Check.Controls.Add(this.panel1);
            this.panel_Data_Check.ForeColor = System.Drawing.Color.White;
            this.panel_Data_Check.Location = new System.Drawing.Point(12, 52);
            this.panel_Data_Check.Name = "panel_Data_Check";
            this.panel_Data_Check.Size = new System.Drawing.Size(1381, 721);
            this.panel_Data_Check.TabIndex = 2109;
            // 
            // panel_Sheet_Index
            // 
            this.panel_Sheet_Index.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.panel_Sheet_Index.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_Sheet_Index.Controls.Add(this.button5);
            this.panel_Sheet_Index.Controls.Add(this.label26);
            this.panel_Sheet_Index.Controls.Add(this.label27);
            this.panel_Sheet_Index.Controls.Add(this.button_Scan_Sheet_Index);
            this.panel_Sheet_Index.Controls.Add(this.textBox5);
            this.panel_Sheet_Index.Controls.Add(this.textBox6);
            this.panel_Sheet_Index.Location = new System.Drawing.Point(1166, 54);
            this.panel_Sheet_Index.Name = "panel_Sheet_Index";
            this.panel_Sheet_Index.Size = new System.Drawing.Size(123, 115);
            this.panel_Sheet_Index.TabIndex = 2324;
            this.panel_Sheet_Index.Visible = false;
            // 
            // button5
            // 
            this.button5.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.button5.Location = new System.Drawing.Point(73, 4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(45, 21);
            this.button5.TabIndex = 2323;
            this.button5.Text = "SI";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(3, 33);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(60, 14);
            this.label26.TabIndex = 3;
            this.label26.Text = "Row Start";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(3, 59);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(54, 14);
            this.label27.TabIndex = 4;
            this.label27.Text = "Row End";
            // 
            // button_Scan_Sheet_Index
            // 
            this.button_Scan_Sheet_Index.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.button_Scan_Sheet_Index.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.button_Scan_Sheet_Index.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button_Scan_Sheet_Index.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkOrange;
            this.button_Scan_Sheet_Index.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Scan_Sheet_Index.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.button_Scan_Sheet_Index.ForeColor = System.Drawing.Color.White;
            this.button_Scan_Sheet_Index.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Scan_Sheet_Index.Location = new System.Drawing.Point(3, 82);
            this.button_Scan_Sheet_Index.Name = "button_Scan_Sheet_Index";
            this.button_Scan_Sheet_Index.Size = new System.Drawing.Size(115, 28);
            this.button_Scan_Sheet_Index.TabIndex = 2105;
            this.button_Scan_Sheet_Index.Text = "Scan Sheet Index";
            this.button_Scan_Sheet_Index.UseVisualStyleBackColor = false;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.ForeColor = System.Drawing.Color.White;
            this.textBox5.Location = new System.Drawing.Point(73, 56);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(45, 20);
            this.textBox5.TabIndex = 18;
            this.textBox5.Text = "78";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.ForeColor = System.Drawing.Color.White;
            this.textBox6.Location = new System.Drawing.Point(73, 30);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(45, 20);
            this.textBox6.TabIndex = 17;
            this.textBox6.Text = "2";
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dataGridView_Filter
            // 
            this.dataGridView_Filter.AllowUserToAddRows = false;
            this.dataGridView_Filter.AllowUserToDeleteRows = false;
            this.dataGridView_Filter.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.dataGridView_Filter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView_Filter.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Filter.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_Filter.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_Filter.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_Filter.Location = new System.Drawing.Point(739, 54);
            this.dataGridView_Filter.Name = "dataGridView_Filter";
            this.dataGridView_Filter.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridView_Filter.RowHeadersWidth = 20;
            this.dataGridView_Filter.Size = new System.Drawing.Size(341, 256);
            this.dataGridView_Filter.TabIndex = 2215;
            this.dataGridView_Filter.Visible = false;
            // 
            // dataGridView_Prelim_Table
            // 
            this.dataGridView_Prelim_Table.AllowUserToAddRows = false;
            this.dataGridView_Prelim_Table.AllowUserToDeleteRows = false;
            this.dataGridView_Prelim_Table.AllowUserToOrderColumns = true;
            this.dataGridView_Prelim_Table.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.dataGridView_Prelim_Table.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView_Prelim_Table.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Prelim_Table.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_Prelim_Table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_Prelim_Table.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView_Prelim_Table.Location = new System.Drawing.Point(537, 54);
            this.dataGridView_Prelim_Table.Name = "dataGridView_Prelim_Table";
            this.dataGridView_Prelim_Table.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridView_Prelim_Table.RowHeadersWidth = 20;
            this.dataGridView_Prelim_Table.Size = new System.Drawing.Size(839, 659);
            this.dataGridView_Prelim_Table.TabIndex = 2214;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.button_Sheet_Index);
            this.panel5.Controls.Add(this.button_Export);
            this.panel5.Controls.Add(this.button3);
            this.panel5.Controls.Add(this.button4_Finalize);
            this.panel5.Controls.Add(this.button_Filter);
            this.panel5.Controls.Add(this.label31);
            this.panel5.Controls.Add(this.button_Prelim_Feature_Table);
            this.panel5.Location = new System.Drawing.Point(537, 30);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(839, 25);
            this.panel5.TabIndex = 2138;
            // 
            // button_Sheet_Index
            // 
            this.button_Sheet_Index.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.button_Sheet_Index.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.button_Sheet_Index.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button_Sheet_Index.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkOrange;
            this.button_Sheet_Index.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Sheet_Index.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.button_Sheet_Index.ForeColor = System.Drawing.Color.White;
            this.button_Sheet_Index.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Sheet_Index.Location = new System.Drawing.Point(628, -1);
            this.button_Sheet_Index.Name = "button_Sheet_Index";
            this.button_Sheet_Index.Size = new System.Drawing.Size(123, 25);
            this.button_Sheet_Index.TabIndex = 2326;
            this.button_Sheet_Index.Text = "Sheet Index";
            this.button_Sheet_Index.UseVisualStyleBackColor = false;
            this.button_Sheet_Index.Click += new System.EventHandler(this.button_Sheet_Index_Click);
            // 
            // button_Export
            // 
            this.button_Export.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.button_Export.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.button_Export.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button_Export.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkOrange;
            this.button_Export.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Export.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.button_Export.ForeColor = System.Drawing.Color.White;
            this.button_Export.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Export.Location = new System.Drawing.Point(750, -1);
            this.button_Export.Name = "button_Export";
            this.button_Export.Size = new System.Drawing.Size(88, 25);
            this.button_Export.TabIndex = 2325;
            this.button_Export.Text = "Export";
            this.button_Export.UseVisualStyleBackColor = false;
            this.button_Export.Click += new System.EventHandler(this.button_Export_Click);
            // 
            // button3
            // 
            this.button3.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.button3.Location = new System.Drawing.Point(496, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(45, 21);
            this.button3.TabIndex = 2324;
            this.button3.Text = "Filter";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4_Finalize
            // 
            this.button4_Finalize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.button4_Finalize.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.button4_Finalize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button4_Finalize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkOrange;
            this.button4_Finalize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4_Finalize.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.button4_Finalize.ForeColor = System.Drawing.Color.White;
            this.button4_Finalize.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4_Finalize.Location = new System.Drawing.Point(541, -1);
            this.button4_Finalize.Name = "button4_Finalize";
            this.button4_Finalize.Size = new System.Drawing.Size(88, 25);
            this.button4_Finalize.TabIndex = 2222;
            this.button4_Finalize.Text = "Finalize";
            this.button4_Finalize.UseVisualStyleBackColor = false;
            this.button4_Finalize.Click += new System.EventHandler(this.button4_Finalize_Click);
            // 
            // button_Filter
            // 
            this.button_Filter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.button_Filter.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.button_Filter.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button_Filter.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkOrange;
            this.button_Filter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Filter.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.button_Filter.ForeColor = System.Drawing.Color.White;
            this.button_Filter.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Filter.Location = new System.Drawing.Point(201, -1);
            this.button_Filter.Name = "button_Filter";
            this.button_Filter.Size = new System.Drawing.Size(341, 25);
            this.button_Filter.TabIndex = 2221;
            this.button_Filter.Text = "Filter";
            this.button_Filter.UseVisualStyleBackColor = false;
            this.button_Filter.Click += new System.EventHandler(this.button_Filter_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.Transparent;
            this.label31.Font = new System.Drawing.Font("Arial Black", 9.75F);
            this.label31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.label31.Location = new System.Drawing.Point(3, 3);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(109, 18);
            this.label31.TabIndex = 2054;
            this.label31.Text = "Feature Table";
            // 
            // button_Prelim_Feature_Table
            // 
            this.button_Prelim_Feature_Table.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.button_Prelim_Feature_Table.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.button_Prelim_Feature_Table.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button_Prelim_Feature_Table.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkOrange;
            this.button_Prelim_Feature_Table.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Prelim_Feature_Table.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.button_Prelim_Feature_Table.ForeColor = System.Drawing.Color.White;
            this.button_Prelim_Feature_Table.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Prelim_Feature_Table.Location = new System.Drawing.Point(114, -1);
            this.button_Prelim_Feature_Table.Name = "button_Prelim_Feature_Table";
            this.button_Prelim_Feature_Table.Size = new System.Drawing.Size(88, 25);
            this.button_Prelim_Feature_Table.TabIndex = 2220;
            this.button_Prelim_Feature_Table.Text = "Prelim Table";
            this.button_Prelim_Feature_Table.UseVisualStyleBackColor = false;
            this.button_Prelim_Feature_Table.Click += new System.EventHandler(this.button_Prelim_Feature_Table_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label10);
            this.panel2.Location = new System.Drawing.Point(270, 30);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(261, 25);
            this.panel2.TabIndex = 2138;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Arial Black", 9.75F);
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.label10.Location = new System.Drawing.Point(3, 3);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(99, 18);
            this.label10.TabIndex = 2054;
            this.label10.Text = "Ground Tally";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.textBox_sht_2);
            this.panel3.Controls.Add(this.label51);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.button_Scan_Ground_Tally);
            this.panel3.Controls.Add(this.textBox_GT_Start_Column);
            this.panel3.Controls.Add(this.textBox_GT_End_Row);
            this.panel3.Controls.Add(this.textBox_GT_Start_Row);
            this.panel3.Controls.Add(this.textBox_GT_End_Column);
            this.panel3.Location = new System.Drawing.Point(270, 54);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(261, 115);
            this.panel3.TabIndex = 2137;
            // 
            // button2
            // 
            this.button2.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.button2.Location = new System.Drawing.Point(211, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(45, 21);
            this.button2.TabIndex = 2323;
            this.button2.Text = "GT";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox_sht_2
            // 
            this.textBox_sht_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.textBox_sht_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_sht_2.ForeColor = System.Drawing.Color.White;
            this.textBox_sht_2.Location = new System.Drawing.Point(88, 4);
            this.textBox_sht_2.Name = "textBox_sht_2";
            this.textBox_sht_2.Size = new System.Drawing.Size(45, 20);
            this.textBox_sht_2.TabIndex = 2108;
            this.textBox_sht_2.Text = "2";
            this.textBox_sht_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label51.ForeColor = System.Drawing.Color.White;
            this.label51.Location = new System.Drawing.Point(3, 7);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(68, 14);
            this.label51.TabIndex = 2107;
            this.label51.Text = "Worksheet";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(3, 33);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(79, 14);
            this.label13.TabIndex = 1;
            this.label13.Text = "Column Start";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(3, 59);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 14);
            this.label14.TabIndex = 2;
            this.label14.Text = "Column End";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(145, 33);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(60, 14);
            this.label15.TabIndex = 3;
            this.label15.Text = "Row Start";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(145, 59);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(54, 14);
            this.label16.TabIndex = 4;
            this.label16.Text = "Row End";
            // 
            // button_Scan_Ground_Tally
            // 
            this.button_Scan_Ground_Tally.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.button_Scan_Ground_Tally.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.button_Scan_Ground_Tally.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button_Scan_Ground_Tally.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkOrange;
            this.button_Scan_Ground_Tally.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Scan_Ground_Tally.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.button_Scan_Ground_Tally.ForeColor = System.Drawing.Color.White;
            this.button_Scan_Ground_Tally.Image = ((System.Drawing.Image)(resources.GetObject("button_Scan_Ground_Tally.Image")));
            this.button_Scan_Ground_Tally.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Scan_Ground_Tally.Location = new System.Drawing.Point(3, 82);
            this.button_Scan_Ground_Tally.Name = "button_Scan_Ground_Tally";
            this.button_Scan_Ground_Tally.Size = new System.Drawing.Size(253, 28);
            this.button_Scan_Ground_Tally.TabIndex = 2105;
            this.button_Scan_Ground_Tally.Text = "Scan Ground Tally";
            this.button_Scan_Ground_Tally.UseVisualStyleBackColor = false;
            this.button_Scan_Ground_Tally.Click += new System.EventHandler(this.button_Scan_Ground_Tally_Click);
            // 
            // textBox_GT_Start_Column
            // 
            this.textBox_GT_Start_Column.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.textBox_GT_Start_Column.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_GT_Start_Column.ForeColor = System.Drawing.Color.White;
            this.textBox_GT_Start_Column.Location = new System.Drawing.Point(88, 30);
            this.textBox_GT_Start_Column.Name = "textBox_GT_Start_Column";
            this.textBox_GT_Start_Column.Size = new System.Drawing.Size(45, 20);
            this.textBox_GT_Start_Column.TabIndex = 15;
            this.textBox_GT_Start_Column.Text = "A";
            this.textBox_GT_Start_Column.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_GT_End_Row
            // 
            this.textBox_GT_End_Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.textBox_GT_End_Row.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_GT_End_Row.ForeColor = System.Drawing.Color.White;
            this.textBox_GT_End_Row.Location = new System.Drawing.Point(211, 56);
            this.textBox_GT_End_Row.Name = "textBox_GT_End_Row";
            this.textBox_GT_End_Row.Size = new System.Drawing.Size(45, 20);
            this.textBox_GT_End_Row.TabIndex = 18;
            this.textBox_GT_End_Row.Text = "66";
            this.textBox_GT_End_Row.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_GT_Start_Row
            // 
            this.textBox_GT_Start_Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.textBox_GT_Start_Row.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_GT_Start_Row.ForeColor = System.Drawing.Color.White;
            this.textBox_GT_Start_Row.Location = new System.Drawing.Point(211, 30);
            this.textBox_GT_Start_Row.Name = "textBox_GT_Start_Row";
            this.textBox_GT_Start_Row.Size = new System.Drawing.Size(45, 20);
            this.textBox_GT_Start_Row.TabIndex = 17;
            this.textBox_GT_Start_Row.Text = "2";
            this.textBox_GT_Start_Row.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_GT_End_Column
            // 
            this.textBox_GT_End_Column.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.textBox_GT_End_Column.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_GT_End_Column.ForeColor = System.Drawing.Color.White;
            this.textBox_GT_End_Column.Location = new System.Drawing.Point(88, 56);
            this.textBox_GT_End_Column.Name = "textBox_GT_End_Column";
            this.textBox_GT_End_Column.Size = new System.Drawing.Size(45, 20);
            this.textBox_GT_End_Column.TabIndex = 16;
            this.textBox_GT_End_Column.Text = "U";
            this.textBox_GT_End_Column.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.checkBox_GT_Heat);
            this.panel10.Controls.Add(this.textBox_color_check);
            this.panel10.Controls.Add(this.checkBox_GT_Coating);
            this.panel10.Controls.Add(this.checkBox_GT_Grade);
            this.panel10.Controls.Add(this.checkBox_GT_Pipe_DIA);
            this.panel10.Controls.Add(this.checkBox_GT_Wall_Thk);
            this.panel10.Controls.Add(this.button6);
            this.panel10.Controls.Add(this.checkBox_GT_MM);
            this.panel10.Controls.Add(this.comboBox_GT_MM);
            this.panel10.Controls.Add(this.comboBox_GT_Wall_Thk);
            this.panel10.Controls.Add(this.comboBox_GT_Heat);
            this.panel10.Controls.Add(this.comboBox_GT_Grade);
            this.panel10.Controls.Add(this.comboBox_GT_Pipe_DIA);
            this.panel10.Controls.Add(this.comboBox_GT_Coating);
            this.panel10.Location = new System.Drawing.Point(270, 167);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(261, 546);
            this.panel10.TabIndex = 2213;
            // 
            // checkBox_GT_Heat
            // 
            this.checkBox_GT_Heat.AutoSize = true;
            this.checkBox_GT_Heat.Location = new System.Drawing.Point(3, 28);
            this.checkBox_GT_Heat.Name = "checkBox_GT_Heat";
            this.checkBox_GT_Heat.Size = new System.Drawing.Size(59, 17);
            this.checkBox_GT_Heat.TabIndex = 2216;
            this.checkBox_GT_Heat.Text = "Heat #";
            this.checkBox_GT_Heat.UseVisualStyleBackColor = true;
            // 
            // textBox_color_check
            // 
            this.textBox_color_check.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.textBox_color_check.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_color_check.ForeColor = System.Drawing.Color.White;
            this.textBox_color_check.Location = new System.Drawing.Point(160, 522);
            this.textBox_color_check.Name = "textBox_color_check";
            this.textBox_color_check.Size = new System.Drawing.Size(45, 20);
            this.textBox_color_check.TabIndex = 2221;
            this.textBox_color_check.Text = "A1743";
            this.textBox_color_check.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // checkBox_GT_Coating
            // 
            this.checkBox_GT_Coating.AutoSize = true;
            this.checkBox_GT_Coating.Location = new System.Drawing.Point(3, 100);
            this.checkBox_GT_Coating.Name = "checkBox_GT_Coating";
            this.checkBox_GT_Coating.Size = new System.Drawing.Size(62, 17);
            this.checkBox_GT_Coating.TabIndex = 2215;
            this.checkBox_GT_Coating.Text = "Coating";
            this.checkBox_GT_Coating.UseVisualStyleBackColor = true;
            // 
            // checkBox_GT_Grade
            // 
            this.checkBox_GT_Grade.AutoSize = true;
            this.checkBox_GT_Grade.Location = new System.Drawing.Point(3, 124);
            this.checkBox_GT_Grade.Name = "checkBox_GT_Grade";
            this.checkBox_GT_Grade.Size = new System.Drawing.Size(55, 17);
            this.checkBox_GT_Grade.TabIndex = 2214;
            this.checkBox_GT_Grade.Text = "Grade";
            this.checkBox_GT_Grade.UseVisualStyleBackColor = true;
            // 
            // checkBox_GT_Pipe_DIA
            // 
            this.checkBox_GT_Pipe_DIA.AutoSize = true;
            this.checkBox_GT_Pipe_DIA.Location = new System.Drawing.Point(3, 76);
            this.checkBox_GT_Pipe_DIA.Name = "checkBox_GT_Pipe_DIA";
            this.checkBox_GT_Pipe_DIA.Size = new System.Drawing.Size(92, 17);
            this.checkBox_GT_Pipe_DIA.TabIndex = 2213;
            this.checkBox_GT_Pipe_DIA.Text = "Pipe Diameter";
            this.checkBox_GT_Pipe_DIA.UseVisualStyleBackColor = true;
            // 
            // checkBox_GT_Wall_Thk
            // 
            this.checkBox_GT_Wall_Thk.AutoSize = true;
            this.checkBox_GT_Wall_Thk.Location = new System.Drawing.Point(3, 52);
            this.checkBox_GT_Wall_Thk.Name = "checkBox_GT_Wall_Thk";
            this.checkBox_GT_Wall_Thk.Size = new System.Drawing.Size(69, 17);
            this.checkBox_GT_Wall_Thk.TabIndex = 2212;
            this.checkBox_GT_Wall_Thk.Text = "Wall Thk";
            this.checkBox_GT_Wall_Thk.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.button6.Location = new System.Drawing.Point(211, 522);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(45, 21);
            this.button6.TabIndex = 2220;
            this.button6.Text = "color";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // checkBox_GT_MM
            // 
            this.checkBox_GT_MM.AutoSize = true;
            this.checkBox_GT_MM.Location = new System.Drawing.Point(3, 4);
            this.checkBox_GT_MM.Name = "checkBox_GT_MM";
            this.checkBox_GT_MM.Size = new System.Drawing.Size(54, 17);
            this.checkBox_GT_MM.TabIndex = 2211;
            this.checkBox_GT_MM.Text = "MM #";
            this.checkBox_GT_MM.UseVisualStyleBackColor = true;
            // 
            // comboBox_GT_MM
            // 
            this.comboBox_GT_MM.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_GT_MM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_GT_MM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_GT_MM.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_GT_MM.ForeColor = System.Drawing.Color.White;
            this.comboBox_GT_MM.FormattingEnabled = true;
            this.comboBox_GT_MM.Location = new System.Drawing.Point(104, 3);
            this.comboBox_GT_MM.Name = "comboBox_GT_MM";
            this.comboBox_GT_MM.Size = new System.Drawing.Size(152, 18);
            this.comboBox_GT_MM.TabIndex = 2185;
            // 
            // comboBox_GT_Wall_Thk
            // 
            this.comboBox_GT_Wall_Thk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_GT_Wall_Thk.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_GT_Wall_Thk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_GT_Wall_Thk.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_GT_Wall_Thk.ForeColor = System.Drawing.Color.White;
            this.comboBox_GT_Wall_Thk.FormattingEnabled = true;
            this.comboBox_GT_Wall_Thk.Location = new System.Drawing.Point(104, 51);
            this.comboBox_GT_Wall_Thk.Name = "comboBox_GT_Wall_Thk";
            this.comboBox_GT_Wall_Thk.Size = new System.Drawing.Size(152, 18);
            this.comboBox_GT_Wall_Thk.TabIndex = 2210;
            // 
            // comboBox_GT_Heat
            // 
            this.comboBox_GT_Heat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_GT_Heat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_GT_Heat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_GT_Heat.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_GT_Heat.ForeColor = System.Drawing.Color.White;
            this.comboBox_GT_Heat.FormattingEnabled = true;
            this.comboBox_GT_Heat.Location = new System.Drawing.Point(104, 27);
            this.comboBox_GT_Heat.Name = "comboBox_GT_Heat";
            this.comboBox_GT_Heat.Size = new System.Drawing.Size(152, 18);
            this.comboBox_GT_Heat.TabIndex = 2189;
            // 
            // comboBox_GT_Grade
            // 
            this.comboBox_GT_Grade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_GT_Grade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_GT_Grade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_GT_Grade.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_GT_Grade.ForeColor = System.Drawing.Color.White;
            this.comboBox_GT_Grade.FormattingEnabled = true;
            this.comboBox_GT_Grade.Location = new System.Drawing.Point(104, 123);
            this.comboBox_GT_Grade.Name = "comboBox_GT_Grade";
            this.comboBox_GT_Grade.Size = new System.Drawing.Size(152, 18);
            this.comboBox_GT_Grade.TabIndex = 2191;
            // 
            // comboBox_GT_Pipe_DIA
            // 
            this.comboBox_GT_Pipe_DIA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_GT_Pipe_DIA.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_GT_Pipe_DIA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_GT_Pipe_DIA.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_GT_Pipe_DIA.ForeColor = System.Drawing.Color.White;
            this.comboBox_GT_Pipe_DIA.FormattingEnabled = true;
            this.comboBox_GT_Pipe_DIA.Location = new System.Drawing.Point(104, 75);
            this.comboBox_GT_Pipe_DIA.Name = "comboBox_GT_Pipe_DIA";
            this.comboBox_GT_Pipe_DIA.Size = new System.Drawing.Size(152, 18);
            this.comboBox_GT_Pipe_DIA.TabIndex = 2193;
            // 
            // comboBox_GT_Coating
            // 
            this.comboBox_GT_Coating.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_GT_Coating.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_GT_Coating.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_GT_Coating.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_GT_Coating.ForeColor = System.Drawing.Color.White;
            this.comboBox_GT_Coating.FormattingEnabled = true;
            this.comboBox_GT_Coating.Location = new System.Drawing.Point(104, 99);
            this.comboBox_GT_Coating.Name = "comboBox_GT_Coating";
            this.comboBox_GT_Coating.Size = new System.Drawing.Size(152, 18);
            this.comboBox_GT_Coating.TabIndex = 2195;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.comboBox_Length);
            this.panel9.Controls.Add(this.checkBox_Length);
            this.panel9.Controls.Add(this.checkBox_Bend_Vert);
            this.panel9.Controls.Add(this.checkBox_Bend_Horiz);
            this.panel9.Controls.Add(this.comboBox_Location);
            this.panel9.Controls.Add(this.comboBox_Cover);
            this.panel9.Controls.Add(this.comboBox_Bend_Vert);
            this.panel9.Controls.Add(this.checkBox_Location);
            this.panel9.Controls.Add(this.comboBox_NG_Elevation);
            this.panel9.Controls.Add(this.comboBox_Bend_Horiz);
            this.panel9.Controls.Add(this.comboBox_NG_Easting);
            this.panel9.Controls.Add(this.comboBox_NG_Northing);
            this.panel9.Controls.Add(this.checkBox_Cover);
            this.panel9.Controls.Add(this.comboBox_NG_PNT);
            this.panel9.Controls.Add(this.checkBox_NG_Elevation);
            this.panel9.Controls.Add(this.comboBox_Grade_Back);
            this.panel9.Controls.Add(this.comboBox_Grade_Ahead);
            this.panel9.Controls.Add(this.checkBox_NG_Easting);
            this.panel9.Controls.Add(this.checkBox_Grade_Ahead);
            this.panel9.Controls.Add(this.checkBox_Grade_Back);
            this.panel9.Controls.Add(this.checkBox_NG_Northing);
            this.panel9.Controls.Add(this.label40);
            this.panel9.Controls.Add(this.checkBox_Coating_Ahead);
            this.panel9.Controls.Add(this.checkBox_Coating_Back);
            this.panel9.Controls.Add(this.label19);
            this.panel9.Controls.Add(this.label20);
            this.panel9.Controls.Add(this.label21);
            this.panel9.Controls.Add(this.label6);
            this.panel9.Controls.Add(this.checkBox_NG_PNT);
            this.panel9.Controls.Add(this.checkBox_Heat_Ahead);
            this.panel9.Controls.Add(this.label18);
            this.panel9.Controls.Add(this.checkBox_Heat_Back);
            this.panel9.Controls.Add(this.checkBox_Pipe_Ahead);
            this.panel9.Controls.Add(this.checkBox_Pipe_Back);
            this.panel9.Controls.Add(this.comboBox_MM_Back);
            this.panel9.Controls.Add(this.comboBox_MM_Ahead);
            this.panel9.Controls.Add(this.checkBox_Wall_Ahead);
            this.panel9.Controls.Add(this.checkBox_Wall_Back);
            this.panel9.Controls.Add(this.comboBox_Wall_Back);
            this.panel9.Controls.Add(this.label25);
            this.panel9.Controls.Add(this.checkBox_MM_Ahead);
            this.panel9.Controls.Add(this.label24);
            this.panel9.Controls.Add(this.label7);
            this.panel9.Controls.Add(this.comboBox_Coating_Back);
            this.panel9.Controls.Add(this.label11);
            this.panel9.Controls.Add(this.comboBox_Pipe_Back);
            this.panel9.Controls.Add(this.comboBox_Coating_Ahead);
            this.panel9.Controls.Add(this.comboBox_Heat_Back);
            this.panel9.Controls.Add(this.comboBox_Wall_Ahead);
            this.panel9.Controls.Add(this.comboBox_Heat_Ahead);
            this.panel9.Controls.Add(this.comboBox_Description);
            this.panel9.Controls.Add(this.comboBox_Pipe_Ahead);
            this.panel9.Controls.Add(this.comboBox_PNT_WM);
            this.panel9.Controls.Add(this.comboBox_Northing);
            this.panel9.Controls.Add(this.checkBox_PNT);
            this.panel9.Controls.Add(this.checkBox_MM_Back);
            this.panel9.Controls.Add(this.comboBox_Feature_Code);
            this.panel9.Controls.Add(this.checkBox_Northing);
            this.panel9.Controls.Add(this.comboBox_Easting);
            this.panel9.Controls.Add(this.checkBox_Station);
            this.panel9.Controls.Add(this.comboBox_Station);
            this.panel9.Controls.Add(this.comboBox_Elevation);
            this.panel9.Controls.Add(this.checkBox_Description);
            this.panel9.Controls.Add(this.checkBox_Feature);
            this.panel9.Controls.Add(this.checkBox_Elevation);
            this.panel9.Controls.Add(this.checkBox_Easting);
            this.panel9.Location = new System.Drawing.Point(3, 167);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(261, 546);
            this.panel9.TabIndex = 2212;
            // 
            // comboBox_Length
            // 
            this.comboBox_Length.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Length.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Length.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Length.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Length.ForeColor = System.Drawing.Color.White;
            this.comboBox_Length.FormattingEnabled = true;
            this.comboBox_Length.Location = new System.Drawing.Point(104, 329);
            this.comboBox_Length.Name = "comboBox_Length";
            this.comboBox_Length.Size = new System.Drawing.Size(152, 18);
            this.comboBox_Length.TabIndex = 2235;
            // 
            // checkBox_Length
            // 
            this.checkBox_Length.AutoSize = true;
            this.checkBox_Length.Location = new System.Drawing.Point(3, 330);
            this.checkBox_Length.Name = "checkBox_Length";
            this.checkBox_Length.Size = new System.Drawing.Size(59, 17);
            this.checkBox_Length.TabIndex = 2234;
            this.checkBox_Length.Text = "Length";
            this.checkBox_Length.UseVisualStyleBackColor = true;
            // 
            // checkBox_Bend_Vert
            // 
            this.checkBox_Bend_Vert.AutoSize = true;
            this.checkBox_Bend_Vert.Location = new System.Drawing.Point(3, 522);
            this.checkBox_Bend_Vert.Name = "checkBox_Bend_Vert";
            this.checkBox_Bend_Vert.Size = new System.Drawing.Size(89, 17);
            this.checkBox_Bend_Vert.TabIndex = 2233;
            this.checkBox_Bend_Vert.Text = "Bend Vertical";
            this.checkBox_Bend_Vert.UseVisualStyleBackColor = true;
            // 
            // checkBox_Bend_Horiz
            // 
            this.checkBox_Bend_Horiz.AutoSize = true;
            this.checkBox_Bend_Horiz.Location = new System.Drawing.Point(3, 498);
            this.checkBox_Bend_Horiz.Name = "checkBox_Bend_Horiz";
            this.checkBox_Bend_Horiz.Size = new System.Drawing.Size(101, 17);
            this.checkBox_Bend_Horiz.TabIndex = 2178;
            this.checkBox_Bend_Horiz.Text = "Bend Horizontal";
            this.checkBox_Bend_Horiz.UseVisualStyleBackColor = true;
            // 
            // comboBox_Location
            // 
            this.comboBox_Location.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Location.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Location.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Location.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Location.ForeColor = System.Drawing.Color.White;
            this.comboBox_Location.FormattingEnabled = true;
            this.comboBox_Location.Location = new System.Drawing.Point(104, 473);
            this.comboBox_Location.Name = "comboBox_Location";
            this.comboBox_Location.Size = new System.Drawing.Size(152, 18);
            this.comboBox_Location.TabIndex = 2232;
            // 
            // comboBox_Cover
            // 
            this.comboBox_Cover.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Cover.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Cover.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Cover.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Cover.ForeColor = System.Drawing.Color.White;
            this.comboBox_Cover.FormattingEnabled = true;
            this.comboBox_Cover.Location = new System.Drawing.Point(104, 449);
            this.comboBox_Cover.Name = "comboBox_Cover";
            this.comboBox_Cover.Size = new System.Drawing.Size(152, 18);
            this.comboBox_Cover.TabIndex = 2231;
            // 
            // comboBox_Bend_Vert
            // 
            this.comboBox_Bend_Vert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Bend_Vert.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Bend_Vert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Bend_Vert.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Bend_Vert.ForeColor = System.Drawing.Color.White;
            this.comboBox_Bend_Vert.FormattingEnabled = true;
            this.comboBox_Bend_Vert.Location = new System.Drawing.Point(104, 521);
            this.comboBox_Bend_Vert.Name = "comboBox_Bend_Vert";
            this.comboBox_Bend_Vert.Size = new System.Drawing.Size(152, 18);
            this.comboBox_Bend_Vert.TabIndex = 2181;
            // 
            // checkBox_Location
            // 
            this.checkBox_Location.AutoSize = true;
            this.checkBox_Location.Location = new System.Drawing.Point(3, 474);
            this.checkBox_Location.Name = "checkBox_Location";
            this.checkBox_Location.Size = new System.Drawing.Size(67, 17);
            this.checkBox_Location.TabIndex = 2165;
            this.checkBox_Location.Text = "Location";
            this.checkBox_Location.UseVisualStyleBackColor = true;
            // 
            // comboBox_NG_Elevation
            // 
            this.comboBox_NG_Elevation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_NG_Elevation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_NG_Elevation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_NG_Elevation.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_NG_Elevation.ForeColor = System.Drawing.Color.White;
            this.comboBox_NG_Elevation.FormattingEnabled = true;
            this.comboBox_NG_Elevation.Location = new System.Drawing.Point(104, 425);
            this.comboBox_NG_Elevation.Name = "comboBox_NG_Elevation";
            this.comboBox_NG_Elevation.Size = new System.Drawing.Size(152, 18);
            this.comboBox_NG_Elevation.TabIndex = 2230;
            // 
            // comboBox_Bend_Horiz
            // 
            this.comboBox_Bend_Horiz.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Bend_Horiz.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Bend_Horiz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Bend_Horiz.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Bend_Horiz.ForeColor = System.Drawing.Color.White;
            this.comboBox_Bend_Horiz.FormattingEnabled = true;
            this.comboBox_Bend_Horiz.Location = new System.Drawing.Point(104, 497);
            this.comboBox_Bend_Horiz.Name = "comboBox_Bend_Horiz";
            this.comboBox_Bend_Horiz.Size = new System.Drawing.Size(152, 18);
            this.comboBox_Bend_Horiz.TabIndex = 2183;
            // 
            // comboBox_NG_Easting
            // 
            this.comboBox_NG_Easting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_NG_Easting.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_NG_Easting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_NG_Easting.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_NG_Easting.ForeColor = System.Drawing.Color.White;
            this.comboBox_NG_Easting.FormattingEnabled = true;
            this.comboBox_NG_Easting.Location = new System.Drawing.Point(104, 401);
            this.comboBox_NG_Easting.Name = "comboBox_NG_Easting";
            this.comboBox_NG_Easting.Size = new System.Drawing.Size(152, 18);
            this.comboBox_NG_Easting.TabIndex = 2229;
            // 
            // comboBox_NG_Northing
            // 
            this.comboBox_NG_Northing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_NG_Northing.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_NG_Northing.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_NG_Northing.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_NG_Northing.ForeColor = System.Drawing.Color.White;
            this.comboBox_NG_Northing.FormattingEnabled = true;
            this.comboBox_NG_Northing.Location = new System.Drawing.Point(104, 377);
            this.comboBox_NG_Northing.Name = "comboBox_NG_Northing";
            this.comboBox_NG_Northing.Size = new System.Drawing.Size(152, 18);
            this.comboBox_NG_Northing.TabIndex = 2228;
            // 
            // checkBox_Cover
            // 
            this.checkBox_Cover.AutoSize = true;
            this.checkBox_Cover.Location = new System.Drawing.Point(3, 450);
            this.checkBox_Cover.Name = "checkBox_Cover";
            this.checkBox_Cover.Size = new System.Drawing.Size(54, 17);
            this.checkBox_Cover.TabIndex = 2163;
            this.checkBox_Cover.Text = "Cover";
            this.checkBox_Cover.UseVisualStyleBackColor = true;
            // 
            // comboBox_NG_PNT
            // 
            this.comboBox_NG_PNT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_NG_PNT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_NG_PNT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_NG_PNT.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_NG_PNT.ForeColor = System.Drawing.Color.White;
            this.comboBox_NG_PNT.FormattingEnabled = true;
            this.comboBox_NG_PNT.Location = new System.Drawing.Point(104, 353);
            this.comboBox_NG_PNT.Name = "comboBox_NG_PNT";
            this.comboBox_NG_PNT.Size = new System.Drawing.Size(152, 18);
            this.comboBox_NG_PNT.TabIndex = 2194;
            // 
            // checkBox_NG_Elevation
            // 
            this.checkBox_NG_Elevation.AutoSize = true;
            this.checkBox_NG_Elevation.Location = new System.Drawing.Point(3, 426);
            this.checkBox_NG_Elevation.Name = "checkBox_NG_Elevation";
            this.checkBox_NG_Elevation.Size = new System.Drawing.Size(89, 17);
            this.checkBox_NG_Elevation.TabIndex = 2162;
            this.checkBox_NG_Elevation.Text = "NG Elevation";
            this.checkBox_NG_Elevation.UseVisualStyleBackColor = true;
            // 
            // comboBox_Grade_Back
            // 
            this.comboBox_Grade_Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Grade_Back.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Grade_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Grade_Back.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Grade_Back.ForeColor = System.Drawing.Color.White;
            this.comboBox_Grade_Back.FormattingEnabled = true;
            this.comboBox_Grade_Back.Location = new System.Drawing.Point(104, 305);
            this.comboBox_Grade_Back.Name = "comboBox_Grade_Back";
            this.comboBox_Grade_Back.Size = new System.Drawing.Size(73, 18);
            this.comboBox_Grade_Back.TabIndex = 2226;
            // 
            // comboBox_Grade_Ahead
            // 
            this.comboBox_Grade_Ahead.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Grade_Ahead.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Grade_Ahead.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Grade_Ahead.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Grade_Ahead.ForeColor = System.Drawing.Color.White;
            this.comboBox_Grade_Ahead.FormattingEnabled = true;
            this.comboBox_Grade_Ahead.Location = new System.Drawing.Point(183, 305);
            this.comboBox_Grade_Ahead.Name = "comboBox_Grade_Ahead";
            this.comboBox_Grade_Ahead.Size = new System.Drawing.Size(73, 18);
            this.comboBox_Grade_Ahead.TabIndex = 2227;
            // 
            // checkBox_NG_Easting
            // 
            this.checkBox_NG_Easting.AutoSize = true;
            this.checkBox_NG_Easting.Location = new System.Drawing.Point(3, 402);
            this.checkBox_NG_Easting.Name = "checkBox_NG_Easting";
            this.checkBox_NG_Easting.Size = new System.Drawing.Size(80, 17);
            this.checkBox_NG_Easting.TabIndex = 2161;
            this.checkBox_NG_Easting.Text = "NG Easting";
            this.checkBox_NG_Easting.UseVisualStyleBackColor = true;
            // 
            // checkBox_Grade_Ahead
            // 
            this.checkBox_Grade_Ahead.AutoSize = true;
            this.checkBox_Grade_Ahead.Location = new System.Drawing.Point(24, 307);
            this.checkBox_Grade_Ahead.Name = "checkBox_Grade_Ahead";
            this.checkBox_Grade_Ahead.Size = new System.Drawing.Size(15, 14);
            this.checkBox_Grade_Ahead.TabIndex = 2225;
            this.checkBox_Grade_Ahead.UseVisualStyleBackColor = true;
            // 
            // checkBox_Grade_Back
            // 
            this.checkBox_Grade_Back.AutoSize = true;
            this.checkBox_Grade_Back.Location = new System.Drawing.Point(3, 307);
            this.checkBox_Grade_Back.Name = "checkBox_Grade_Back";
            this.checkBox_Grade_Back.Size = new System.Drawing.Size(15, 14);
            this.checkBox_Grade_Back.TabIndex = 2224;
            this.checkBox_Grade_Back.UseVisualStyleBackColor = true;
            // 
            // checkBox_NG_Northing
            // 
            this.checkBox_NG_Northing.AutoSize = true;
            this.checkBox_NG_Northing.Location = new System.Drawing.Point(3, 378);
            this.checkBox_NG_Northing.Name = "checkBox_NG_Northing";
            this.checkBox_NG_Northing.Size = new System.Drawing.Size(85, 17);
            this.checkBox_NG_Northing.TabIndex = 2160;
            this.checkBox_NG_Northing.Text = "NG Northing";
            this.checkBox_NG_Northing.UseVisualStyleBackColor = true;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label40.ForeColor = System.Drawing.Color.White;
            this.label40.Location = new System.Drawing.Point(43, 307);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(40, 14);
            this.label40.TabIndex = 2221;
            this.label40.Text = "Grade";
            // 
            // checkBox_Coating_Ahead
            // 
            this.checkBox_Coating_Ahead.AutoSize = true;
            this.checkBox_Coating_Ahead.Location = new System.Drawing.Point(24, 283);
            this.checkBox_Coating_Ahead.Name = "checkBox_Coating_Ahead";
            this.checkBox_Coating_Ahead.Size = new System.Drawing.Size(15, 14);
            this.checkBox_Coating_Ahead.TabIndex = 2220;
            this.checkBox_Coating_Ahead.UseVisualStyleBackColor = true;
            // 
            // checkBox_Coating_Back
            // 
            this.checkBox_Coating_Back.AutoSize = true;
            this.checkBox_Coating_Back.Location = new System.Drawing.Point(3, 283);
            this.checkBox_Coating_Back.Name = "checkBox_Coating_Back";
            this.checkBox_Coating_Back.Size = new System.Drawing.Size(15, 14);
            this.checkBox_Coating_Back.TabIndex = 2219;
            this.checkBox_Coating_Back.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(43, 283);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(49, 14);
            this.label19.TabIndex = 2208;
            this.label19.Text = "Coating";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(43, 259);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(40, 14);
            this.label20.TabIndex = 2205;
            this.label20.Text = "Heat #";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(43, 235);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(40, 14);
            this.label21.TabIndex = 2202;
            this.label21.Text = "Pipe #";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(43, 187);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 14);
            this.label6.TabIndex = 2194;
            this.label6.Text = "MM #";
            // 
            // checkBox_NG_PNT
            // 
            this.checkBox_NG_PNT.AutoSize = true;
            this.checkBox_NG_PNT.Location = new System.Drawing.Point(3, 354);
            this.checkBox_NG_PNT.Name = "checkBox_NG_PNT";
            this.checkBox_NG_PNT.Size = new System.Drawing.Size(79, 17);
            this.checkBox_NG_PNT.TabIndex = 2159;
            this.checkBox_NG_PNT.Text = "NG Point #";
            this.checkBox_NG_PNT.UseVisualStyleBackColor = true;
            // 
            // checkBox_Heat_Ahead
            // 
            this.checkBox_Heat_Ahead.AutoSize = true;
            this.checkBox_Heat_Ahead.Location = new System.Drawing.Point(24, 259);
            this.checkBox_Heat_Ahead.Name = "checkBox_Heat_Ahead";
            this.checkBox_Heat_Ahead.Size = new System.Drawing.Size(15, 14);
            this.checkBox_Heat_Ahead.TabIndex = 2218;
            this.checkBox_Heat_Ahead.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(43, 211);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 14);
            this.label18.TabIndex = 2199;
            this.label18.Text = "Wall Thk";
            // 
            // checkBox_Heat_Back
            // 
            this.checkBox_Heat_Back.AutoSize = true;
            this.checkBox_Heat_Back.Location = new System.Drawing.Point(3, 259);
            this.checkBox_Heat_Back.Name = "checkBox_Heat_Back";
            this.checkBox_Heat_Back.Size = new System.Drawing.Size(15, 14);
            this.checkBox_Heat_Back.TabIndex = 2217;
            this.checkBox_Heat_Back.UseVisualStyleBackColor = true;
            // 
            // checkBox_Pipe_Ahead
            // 
            this.checkBox_Pipe_Ahead.AutoSize = true;
            this.checkBox_Pipe_Ahead.Location = new System.Drawing.Point(24, 235);
            this.checkBox_Pipe_Ahead.Name = "checkBox_Pipe_Ahead";
            this.checkBox_Pipe_Ahead.Size = new System.Drawing.Size(15, 14);
            this.checkBox_Pipe_Ahead.TabIndex = 2216;
            this.checkBox_Pipe_Ahead.UseVisualStyleBackColor = true;
            // 
            // checkBox_Pipe_Back
            // 
            this.checkBox_Pipe_Back.AutoSize = true;
            this.checkBox_Pipe_Back.Location = new System.Drawing.Point(3, 235);
            this.checkBox_Pipe_Back.Name = "checkBox_Pipe_Back";
            this.checkBox_Pipe_Back.Size = new System.Drawing.Size(15, 14);
            this.checkBox_Pipe_Back.TabIndex = 2215;
            this.checkBox_Pipe_Back.UseVisualStyleBackColor = true;
            // 
            // comboBox_MM_Back
            // 
            this.comboBox_MM_Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_MM_Back.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_MM_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_MM_Back.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_MM_Back.ForeColor = System.Drawing.Color.White;
            this.comboBox_MM_Back.FormattingEnabled = true;
            this.comboBox_MM_Back.Location = new System.Drawing.Point(104, 185);
            this.comboBox_MM_Back.Name = "comboBox_MM_Back";
            this.comboBox_MM_Back.Size = new System.Drawing.Size(73, 18);
            this.comboBox_MM_Back.TabIndex = 2162;
            // 
            // comboBox_MM_Ahead
            // 
            this.comboBox_MM_Ahead.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_MM_Ahead.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_MM_Ahead.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_MM_Ahead.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_MM_Ahead.ForeColor = System.Drawing.Color.White;
            this.comboBox_MM_Ahead.FormattingEnabled = true;
            this.comboBox_MM_Ahead.Location = new System.Drawing.Point(183, 185);
            this.comboBox_MM_Ahead.Name = "comboBox_MM_Ahead";
            this.comboBox_MM_Ahead.Size = new System.Drawing.Size(73, 18);
            this.comboBox_MM_Ahead.TabIndex = 2163;
            // 
            // checkBox_Wall_Ahead
            // 
            this.checkBox_Wall_Ahead.AutoSize = true;
            this.checkBox_Wall_Ahead.Location = new System.Drawing.Point(24, 211);
            this.checkBox_Wall_Ahead.Name = "checkBox_Wall_Ahead";
            this.checkBox_Wall_Ahead.Size = new System.Drawing.Size(15, 14);
            this.checkBox_Wall_Ahead.TabIndex = 2214;
            this.checkBox_Wall_Ahead.UseVisualStyleBackColor = true;
            // 
            // checkBox_Wall_Back
            // 
            this.checkBox_Wall_Back.AutoSize = true;
            this.checkBox_Wall_Back.Location = new System.Drawing.Point(3, 211);
            this.checkBox_Wall_Back.Name = "checkBox_Wall_Back";
            this.checkBox_Wall_Back.Size = new System.Drawing.Size(15, 14);
            this.checkBox_Wall_Back.TabIndex = 2213;
            this.checkBox_Wall_Back.UseVisualStyleBackColor = true;
            // 
            // comboBox_Wall_Back
            // 
            this.comboBox_Wall_Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Wall_Back.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Wall_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Wall_Back.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Wall_Back.ForeColor = System.Drawing.Color.White;
            this.comboBox_Wall_Back.FormattingEnabled = true;
            this.comboBox_Wall_Back.Location = new System.Drawing.Point(104, 209);
            this.comboBox_Wall_Back.Name = "comboBox_Wall_Back";
            this.comboBox_Wall_Back.Size = new System.Drawing.Size(73, 18);
            this.comboBox_Wall_Back.TabIndex = 2167;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(20, 168);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(22, 14);
            this.label25.TabIndex = 2212;
            this.label25.Text = "AH";
            // 
            // checkBox_MM_Ahead
            // 
            this.checkBox_MM_Ahead.AutoSize = true;
            this.checkBox_MM_Ahead.Location = new System.Drawing.Point(24, 187);
            this.checkBox_MM_Ahead.Name = "checkBox_MM_Ahead";
            this.checkBox_MM_Ahead.Size = new System.Drawing.Size(15, 14);
            this.checkBox_MM_Ahead.TabIndex = 2195;
            this.checkBox_MM_Ahead.UseVisualStyleBackColor = true;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(0, 168);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(21, 14);
            this.label24.TabIndex = 2211;
            this.label24.Text = "BK";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(124, 168);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 14);
            this.label7.TabIndex = 2197;
            this.label7.Text = "Back";
            // 
            // comboBox_Coating_Back
            // 
            this.comboBox_Coating_Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Coating_Back.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Coating_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Coating_Back.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Coating_Back.ForeColor = System.Drawing.Color.White;
            this.comboBox_Coating_Back.FormattingEnabled = true;
            this.comboBox_Coating_Back.Location = new System.Drawing.Point(104, 281);
            this.comboBox_Coating_Back.Name = "comboBox_Coating_Back";
            this.comboBox_Coating_Back.Size = new System.Drawing.Size(73, 18);
            this.comboBox_Coating_Back.TabIndex = 2176;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(198, 168);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 14);
            this.label11.TabIndex = 2198;
            this.label11.Text = "Ahead";
            // 
            // comboBox_Pipe_Back
            // 
            this.comboBox_Pipe_Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Pipe_Back.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Pipe_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Pipe_Back.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Pipe_Back.ForeColor = System.Drawing.Color.White;
            this.comboBox_Pipe_Back.FormattingEnabled = true;
            this.comboBox_Pipe_Back.Location = new System.Drawing.Point(104, 233);
            this.comboBox_Pipe_Back.Name = "comboBox_Pipe_Back";
            this.comboBox_Pipe_Back.Size = new System.Drawing.Size(73, 18);
            this.comboBox_Pipe_Back.TabIndex = 2170;
            // 
            // comboBox_Coating_Ahead
            // 
            this.comboBox_Coating_Ahead.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Coating_Ahead.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Coating_Ahead.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Coating_Ahead.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Coating_Ahead.ForeColor = System.Drawing.Color.White;
            this.comboBox_Coating_Ahead.FormattingEnabled = true;
            this.comboBox_Coating_Ahead.Location = new System.Drawing.Point(183, 281);
            this.comboBox_Coating_Ahead.Name = "comboBox_Coating_Ahead";
            this.comboBox_Coating_Ahead.Size = new System.Drawing.Size(73, 18);
            this.comboBox_Coating_Ahead.TabIndex = 2177;
            // 
            // comboBox_Heat_Back
            // 
            this.comboBox_Heat_Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Heat_Back.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Heat_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Heat_Back.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Heat_Back.ForeColor = System.Drawing.Color.White;
            this.comboBox_Heat_Back.FormattingEnabled = true;
            this.comboBox_Heat_Back.Location = new System.Drawing.Point(104, 257);
            this.comboBox_Heat_Back.Name = "comboBox_Heat_Back";
            this.comboBox_Heat_Back.Size = new System.Drawing.Size(73, 18);
            this.comboBox_Heat_Back.TabIndex = 2173;
            // 
            // comboBox_Wall_Ahead
            // 
            this.comboBox_Wall_Ahead.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Wall_Ahead.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Wall_Ahead.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Wall_Ahead.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Wall_Ahead.ForeColor = System.Drawing.Color.White;
            this.comboBox_Wall_Ahead.FormattingEnabled = true;
            this.comboBox_Wall_Ahead.Location = new System.Drawing.Point(183, 209);
            this.comboBox_Wall_Ahead.Name = "comboBox_Wall_Ahead";
            this.comboBox_Wall_Ahead.Size = new System.Drawing.Size(73, 18);
            this.comboBox_Wall_Ahead.TabIndex = 2168;
            // 
            // comboBox_Heat_Ahead
            // 
            this.comboBox_Heat_Ahead.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Heat_Ahead.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Heat_Ahead.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Heat_Ahead.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Heat_Ahead.ForeColor = System.Drawing.Color.White;
            this.comboBox_Heat_Ahead.FormattingEnabled = true;
            this.comboBox_Heat_Ahead.Location = new System.Drawing.Point(183, 257);
            this.comboBox_Heat_Ahead.Name = "comboBox_Heat_Ahead";
            this.comboBox_Heat_Ahead.Size = new System.Drawing.Size(73, 18);
            this.comboBox_Heat_Ahead.TabIndex = 2174;
            // 
            // comboBox_Description
            // 
            this.comboBox_Description.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Description.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Description.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Description.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Description.ForeColor = System.Drawing.Color.White;
            this.comboBox_Description.FormattingEnabled = true;
            this.comboBox_Description.Location = new System.Drawing.Point(104, 123);
            this.comboBox_Description.Name = "comboBox_Description";
            this.comboBox_Description.Size = new System.Drawing.Size(152, 18);
            this.comboBox_Description.TabIndex = 2185;
            // 
            // comboBox_Pipe_Ahead
            // 
            this.comboBox_Pipe_Ahead.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Pipe_Ahead.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Pipe_Ahead.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Pipe_Ahead.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Pipe_Ahead.ForeColor = System.Drawing.Color.White;
            this.comboBox_Pipe_Ahead.FormattingEnabled = true;
            this.comboBox_Pipe_Ahead.Location = new System.Drawing.Point(183, 233);
            this.comboBox_Pipe_Ahead.Name = "comboBox_Pipe_Ahead";
            this.comboBox_Pipe_Ahead.Size = new System.Drawing.Size(73, 18);
            this.comboBox_Pipe_Ahead.TabIndex = 2171;
            // 
            // comboBox_PNT_WM
            // 
            this.comboBox_PNT_WM.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_PNT_WM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_PNT_WM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_PNT_WM.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_PNT_WM.ForeColor = System.Drawing.Color.White;
            this.comboBox_PNT_WM.FormattingEnabled = true;
            this.comboBox_PNT_WM.Location = new System.Drawing.Point(104, 3);
            this.comboBox_PNT_WM.Name = "comboBox_PNT_WM";
            this.comboBox_PNT_WM.Size = new System.Drawing.Size(152, 18);
            this.comboBox_PNT_WM.TabIndex = 2146;
            // 
            // comboBox_Northing
            // 
            this.comboBox_Northing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Northing.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Northing.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Northing.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Northing.ForeColor = System.Drawing.Color.White;
            this.comboBox_Northing.FormattingEnabled = true;
            this.comboBox_Northing.Location = new System.Drawing.Point(104, 27);
            this.comboBox_Northing.Name = "comboBox_Northing";
            this.comboBox_Northing.Size = new System.Drawing.Size(152, 18);
            this.comboBox_Northing.TabIndex = 2148;
            // 
            // checkBox_PNT
            // 
            this.checkBox_PNT.AutoSize = true;
            this.checkBox_PNT.Location = new System.Drawing.Point(3, 4);
            this.checkBox_PNT.Name = "checkBox_PNT";
            this.checkBox_PNT.Size = new System.Drawing.Size(60, 17);
            this.checkBox_PNT.TabIndex = 2139;
            this.checkBox_PNT.Text = "Point #";
            this.checkBox_PNT.UseVisualStyleBackColor = true;
            // 
            // checkBox_MM_Back
            // 
            this.checkBox_MM_Back.AutoSize = true;
            this.checkBox_MM_Back.Location = new System.Drawing.Point(3, 187);
            this.checkBox_MM_Back.Name = "checkBox_MM_Back";
            this.checkBox_MM_Back.Size = new System.Drawing.Size(15, 14);
            this.checkBox_MM_Back.TabIndex = 2147;
            this.checkBox_MM_Back.UseVisualStyleBackColor = true;
            // 
            // comboBox_Feature_Code
            // 
            this.comboBox_Feature_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Feature_Code.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Feature_Code.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Feature_Code.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Feature_Code.ForeColor = System.Drawing.Color.White;
            this.comboBox_Feature_Code.FormattingEnabled = true;
            this.comboBox_Feature_Code.Location = new System.Drawing.Point(104, 99);
            this.comboBox_Feature_Code.Name = "comboBox_Feature_Code";
            this.comboBox_Feature_Code.Size = new System.Drawing.Size(152, 18);
            this.comboBox_Feature_Code.TabIndex = 2144;
            // 
            // checkBox_Northing
            // 
            this.checkBox_Northing.AutoSize = true;
            this.checkBox_Northing.Location = new System.Drawing.Point(3, 28);
            this.checkBox_Northing.Name = "checkBox_Northing";
            this.checkBox_Northing.Size = new System.Drawing.Size(66, 17);
            this.checkBox_Northing.TabIndex = 2141;
            this.checkBox_Northing.Text = "Northing";
            this.checkBox_Northing.UseVisualStyleBackColor = true;
            // 
            // comboBox_Easting
            // 
            this.comboBox_Easting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Easting.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Easting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Easting.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Easting.ForeColor = System.Drawing.Color.White;
            this.comboBox_Easting.FormattingEnabled = true;
            this.comboBox_Easting.Location = new System.Drawing.Point(104, 51);
            this.comboBox_Easting.Name = "comboBox_Easting";
            this.comboBox_Easting.Size = new System.Drawing.Size(152, 18);
            this.comboBox_Easting.TabIndex = 2150;
            // 
            // checkBox_Station
            // 
            this.checkBox_Station.AutoSize = true;
            this.checkBox_Station.Location = new System.Drawing.Point(3, 148);
            this.checkBox_Station.Name = "checkBox_Station";
            this.checkBox_Station.Size = new System.Drawing.Size(59, 17);
            this.checkBox_Station.TabIndex = 2146;
            this.checkBox_Station.Text = "Station";
            this.checkBox_Station.UseVisualStyleBackColor = true;
            // 
            // comboBox_Station
            // 
            this.comboBox_Station.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Station.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Station.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Station.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Station.ForeColor = System.Drawing.Color.White;
            this.comboBox_Station.FormattingEnabled = true;
            this.comboBox_Station.Location = new System.Drawing.Point(104, 147);
            this.comboBox_Station.Name = "comboBox_Station";
            this.comboBox_Station.Size = new System.Drawing.Size(152, 18);
            this.comboBox_Station.TabIndex = 2156;
            // 
            // comboBox_Elevation
            // 
            this.comboBox_Elevation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.comboBox_Elevation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Elevation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Elevation.Font = new System.Drawing.Font("Arial", 6.25F, System.Drawing.FontStyle.Bold);
            this.comboBox_Elevation.ForeColor = System.Drawing.Color.White;
            this.comboBox_Elevation.FormattingEnabled = true;
            this.comboBox_Elevation.Location = new System.Drawing.Point(104, 75);
            this.comboBox_Elevation.Name = "comboBox_Elevation";
            this.comboBox_Elevation.Size = new System.Drawing.Size(152, 18);
            this.comboBox_Elevation.TabIndex = 2152;
            // 
            // checkBox_Description
            // 
            this.checkBox_Description.AutoSize = true;
            this.checkBox_Description.Location = new System.Drawing.Point(3, 124);
            this.checkBox_Description.Name = "checkBox_Description";
            this.checkBox_Description.Size = new System.Drawing.Size(79, 17);
            this.checkBox_Description.TabIndex = 2145;
            this.checkBox_Description.Text = "Description";
            this.checkBox_Description.UseVisualStyleBackColor = true;
            // 
            // checkBox_Feature
            // 
            this.checkBox_Feature.AutoSize = true;
            this.checkBox_Feature.Location = new System.Drawing.Point(3, 100);
            this.checkBox_Feature.Name = "checkBox_Feature";
            this.checkBox_Feature.Size = new System.Drawing.Size(62, 17);
            this.checkBox_Feature.TabIndex = 2144;
            this.checkBox_Feature.Text = "Feature";
            this.checkBox_Feature.UseVisualStyleBackColor = true;
            // 
            // checkBox_Elevation
            // 
            this.checkBox_Elevation.AutoSize = true;
            this.checkBox_Elevation.Location = new System.Drawing.Point(3, 76);
            this.checkBox_Elevation.Name = "checkBox_Elevation";
            this.checkBox_Elevation.Size = new System.Drawing.Size(70, 17);
            this.checkBox_Elevation.TabIndex = 2143;
            this.checkBox_Elevation.Text = "Elevation";
            this.checkBox_Elevation.UseVisualStyleBackColor = true;
            // 
            // checkBox_Easting
            // 
            this.checkBox_Easting.AutoSize = true;
            this.checkBox_Easting.Location = new System.Drawing.Point(3, 52);
            this.checkBox_Easting.Name = "checkBox_Easting";
            this.checkBox_Easting.Size = new System.Drawing.Size(61, 17);
            this.checkBox_Easting.TabIndex = 2142;
            this.checkBox_Easting.Text = "Easting";
            this.checkBox_Easting.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.label17);
            this.panel8.Location = new System.Drawing.Point(-1, -1);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1381, 25);
            this.panel8.TabIndex = 2144;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Arial Black", 9.75F);
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.label17.Location = new System.Drawing.Point(3, 3);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(84, 18);
            this.label17.TabIndex = 2054;
            this.label17.Text = "AS-BUILTS";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.label12);
            this.panel7.Location = new System.Drawing.Point(3, 30);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(261, 25);
            this.panel7.TabIndex = 2136;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Arial Black", 9.75F);
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.label12.Location = new System.Drawing.Point(3, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 18);
            this.label12.TabIndex = 2054;
            this.label12.Text = "Weld Map";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.textBox_sht_1);
            this.panel1.Controls.Add(this.label50);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.button_Scan_Weld_Map);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.textBox_WM_Start_Column);
            this.panel1.Controls.Add(this.textBox_WM_End_Column);
            this.panel1.Controls.Add(this.textBox_WM_Start_Row);
            this.panel1.Controls.Add(this.textBox_WM_End_Row);
            this.panel1.Location = new System.Drawing.Point(3, 54);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(261, 115);
            this.panel1.TabIndex = 2107;
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.button1.Location = new System.Drawing.Point(211, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(45, 21);
            this.button1.TabIndex = 2322;
            this.button1.Text = "Weld";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox_sht_1
            // 
            this.textBox_sht_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.textBox_sht_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_sht_1.ForeColor = System.Drawing.Color.White;
            this.textBox_sht_1.Location = new System.Drawing.Point(88, 4);
            this.textBox_sht_1.Name = "textBox_sht_1";
            this.textBox_sht_1.Size = new System.Drawing.Size(45, 20);
            this.textBox_sht_1.TabIndex = 2106;
            this.textBox_sht_1.Text = "1";
            this.textBox_sht_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label50.ForeColor = System.Drawing.Color.White;
            this.label50.Location = new System.Drawing.Point(3, 7);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(68, 14);
            this.label50.TabIndex = 2105;
            this.label50.Text = "Worksheet";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 14);
            this.label1.TabIndex = 1;
            this.label1.Text = "Column Start";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(3, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 14);
            this.label2.TabIndex = 2;
            this.label2.Text = "Column End";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(145, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 14);
            this.label4.TabIndex = 3;
            this.label4.Text = "Row Start";
            // 
            // button_Scan_Weld_Map
            // 
            this.button_Scan_Weld_Map.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.button_Scan_Weld_Map.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.button_Scan_Weld_Map.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button_Scan_Weld_Map.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkOrange;
            this.button_Scan_Weld_Map.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Scan_Weld_Map.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.button_Scan_Weld_Map.ForeColor = System.Drawing.Color.White;
            this.button_Scan_Weld_Map.Image = ((System.Drawing.Image)(resources.GetObject("button_Scan_Weld_Map.Image")));
            this.button_Scan_Weld_Map.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Scan_Weld_Map.Location = new System.Drawing.Point(3, 82);
            this.button_Scan_Weld_Map.Name = "button_Scan_Weld_Map";
            this.button_Scan_Weld_Map.Size = new System.Drawing.Size(253, 28);
            this.button_Scan_Weld_Map.TabIndex = 2104;
            this.button_Scan_Weld_Map.Text = "Scan Weld Map";
            this.button_Scan_Weld_Map.UseVisualStyleBackColor = false;
            this.button_Scan_Weld_Map.Click += new System.EventHandler(this.button_Scan_Weld_Map_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(145, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 14);
            this.label3.TabIndex = 4;
            this.label3.Text = "Row End";
            // 
            // textBox_WM_Start_Column
            // 
            this.textBox_WM_Start_Column.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.textBox_WM_Start_Column.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_WM_Start_Column.ForeColor = System.Drawing.Color.White;
            this.textBox_WM_Start_Column.Location = new System.Drawing.Point(88, 30);
            this.textBox_WM_Start_Column.Name = "textBox_WM_Start_Column";
            this.textBox_WM_Start_Column.Size = new System.Drawing.Size(45, 20);
            this.textBox_WM_Start_Column.TabIndex = 5;
            this.textBox_WM_Start_Column.Text = "A";
            this.textBox_WM_Start_Column.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_WM_End_Column
            // 
            this.textBox_WM_End_Column.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.textBox_WM_End_Column.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_WM_End_Column.ForeColor = System.Drawing.Color.White;
            this.textBox_WM_End_Column.Location = new System.Drawing.Point(88, 56);
            this.textBox_WM_End_Column.Name = "textBox_WM_End_Column";
            this.textBox_WM_End_Column.Size = new System.Drawing.Size(45, 20);
            this.textBox_WM_End_Column.TabIndex = 6;
            this.textBox_WM_End_Column.Text = "Z";
            this.textBox_WM_End_Column.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_WM_Start_Row
            // 
            this.textBox_WM_Start_Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.textBox_WM_Start_Row.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_WM_Start_Row.ForeColor = System.Drawing.Color.White;
            this.textBox_WM_Start_Row.Location = new System.Drawing.Point(211, 30);
            this.textBox_WM_Start_Row.Name = "textBox_WM_Start_Row";
            this.textBox_WM_Start_Row.Size = new System.Drawing.Size(45, 20);
            this.textBox_WM_Start_Row.TabIndex = 7;
            this.textBox_WM_Start_Row.Text = "2";
            this.textBox_WM_Start_Row.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_WM_End_Row
            // 
            this.textBox_WM_End_Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(55)))));
            this.textBox_WM_End_Row.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_WM_End_Row.ForeColor = System.Drawing.Color.White;
            this.textBox_WM_End_Row.Location = new System.Drawing.Point(211, 56);
            this.textBox_WM_End_Row.Name = "textBox_WM_End_Row";
            this.textBox_WM_End_Row.Size = new System.Drawing.Size(45, 20);
            this.textBox_WM_End_Row.TabIndex = 8;
            this.textBox_WM_End_Row.Text = "3558";
            this.textBox_WM_End_Row.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(66)))));
            this.ClientSize = new System.Drawing.Size(1405, 785);
            this.Controls.Add(this.panel_Data_Check);
            this.Controls.Add(this.panel_header);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_header.ResumeLayout(false);
            this.panel_header.PerformLayout();
            this.panel_Data_Check.ResumeLayout(false);
            this.panel_Sheet_Index.ResumeLayout(false);
            this.panel_Sheet_Index.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Filter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Prelim_Table)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_header;
        private System.Windows.Forms.Button button_minimize;
        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Label label_mm;
        private System.Windows.Forms.Panel panel_Data_Check;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.ComboBox comboBox_Description;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox_sht_1;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_Scan_Weld_Map;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_WM_Start_Column;
        private System.Windows.Forms.TextBox textBox_WM_End_Column;
        private System.Windows.Forms.TextBox textBox_WM_Start_Row;
        private System.Windows.Forms.TextBox textBox_WM_End_Row;
        private System.Windows.Forms.ComboBox comboBox_Feature_Code;
        private System.Windows.Forms.ComboBox comboBox_PNT_WM;
        private System.Windows.Forms.ComboBox comboBox_Northing;
        private System.Windows.Forms.ComboBox comboBox_Easting;
        private System.Windows.Forms.ComboBox comboBox_Elevation;
        private System.Windows.Forms.ComboBox comboBox_Station;
        private System.Windows.Forms.ComboBox comboBox_MM_Ahead;
        private System.Windows.Forms.ComboBox comboBox_MM_Back;
        private System.Windows.Forms.ComboBox comboBox_Wall_Back;
        private System.Windows.Forms.ComboBox comboBox_Wall_Ahead;
        private System.Windows.Forms.ComboBox comboBox_Pipe_Back;
        private System.Windows.Forms.ComboBox comboBox_Pipe_Ahead;
        private System.Windows.Forms.ComboBox comboBox_Heat_Back;
        private System.Windows.Forms.ComboBox comboBox_Bend_Horiz;
        private System.Windows.Forms.ComboBox comboBox_Heat_Ahead;
        private System.Windows.Forms.ComboBox comboBox_Bend_Vert;
        private System.Windows.Forms.ComboBox comboBox_Coating_Back;
        private System.Windows.Forms.ComboBox comboBox_Coating_Ahead;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox_sht_2;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button_Scan_Ground_Tally;
        private System.Windows.Forms.TextBox textBox_GT_Start_Column;
        private System.Windows.Forms.TextBox textBox_GT_End_Row;
        private System.Windows.Forms.TextBox textBox_GT_Start_Row;
        private System.Windows.Forms.TextBox textBox_GT_End_Column;
        private System.Windows.Forms.ComboBox comboBox_GT_MM;
        private System.Windows.Forms.ComboBox comboBox_GT_Wall_Thk;
        private System.Windows.Forms.ComboBox comboBox_GT_Heat;
        private System.Windows.Forms.ComboBox comboBox_GT_Grade;
        private System.Windows.Forms.ComboBox comboBox_GT_Pipe_DIA;
        private System.Windows.Forms.ComboBox comboBox_GT_Coating;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.CheckBox checkBox_PNT;
        private System.Windows.Forms.Button button_Prelim_Feature_Table;
        private System.Windows.Forms.CheckBox checkBox_Location;
        private System.Windows.Forms.CheckBox checkBox_Cover;
        private System.Windows.Forms.CheckBox checkBox_NG_Elevation;
        private System.Windows.Forms.CheckBox checkBox_NG_Easting;
        private System.Windows.Forms.CheckBox checkBox_NG_Northing;
        private System.Windows.Forms.CheckBox checkBox_NG_PNT;
        private System.Windows.Forms.CheckBox checkBox_Northing;
        private System.Windows.Forms.CheckBox checkBox_Station;
        private System.Windows.Forms.CheckBox checkBox_Description;
        private System.Windows.Forms.CheckBox checkBox_Feature;
        private System.Windows.Forms.CheckBox checkBox_Elevation;
        private System.Windows.Forms.CheckBox checkBox_Easting;
        private System.Windows.Forms.CheckBox checkBox_Bend_Horiz;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.CheckBox checkBox_MM_Ahead;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.CheckBox checkBox_MM_Back;
        private System.Windows.Forms.ComboBox comboBox_Location;
        private System.Windows.Forms.ComboBox comboBox_Cover;
        private System.Windows.Forms.ComboBox comboBox_NG_Elevation;
        private System.Windows.Forms.ComboBox comboBox_NG_Easting;
        private System.Windows.Forms.ComboBox comboBox_NG_Northing;
        private System.Windows.Forms.ComboBox comboBox_NG_PNT;
        private System.Windows.Forms.ComboBox comboBox_Grade_Back;
        private System.Windows.Forms.ComboBox comboBox_Grade_Ahead;
        private System.Windows.Forms.CheckBox checkBox_Grade_Ahead;
        private System.Windows.Forms.CheckBox checkBox_Grade_Back;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.CheckBox checkBox_Coating_Ahead;
        private System.Windows.Forms.CheckBox checkBox_Coating_Back;
        private System.Windows.Forms.CheckBox checkBox_Heat_Ahead;
        private System.Windows.Forms.CheckBox checkBox_Heat_Back;
        private System.Windows.Forms.CheckBox checkBox_Pipe_Ahead;
        private System.Windows.Forms.CheckBox checkBox_Pipe_Back;
        private System.Windows.Forms.CheckBox checkBox_Wall_Ahead;
        private System.Windows.Forms.CheckBox checkBox_Wall_Back;
        private System.Windows.Forms.ComboBox comboBox_Length;
        private System.Windows.Forms.CheckBox checkBox_Length;
        private System.Windows.Forms.CheckBox checkBox_Bend_Vert;
        private System.Windows.Forms.TextBox textBox_color_check;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.CheckBox checkBox_GT_Coating;
        private System.Windows.Forms.CheckBox checkBox_GT_Grade;
        private System.Windows.Forms.CheckBox checkBox_GT_Pipe_DIA;
        private System.Windows.Forms.CheckBox checkBox_GT_Wall_Thk;
        private System.Windows.Forms.CheckBox checkBox_GT_MM;
        private System.Windows.Forms.CheckBox checkBox_GT_Heat;
        private System.Windows.Forms.DataGridView dataGridView_Prelim_Table;
        private System.Windows.Forms.DataGridView dataGridView_Filter;
        private System.Windows.Forms.Button button_Filter;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4_Finalize;
        private System.Windows.Forms.Button button_Export;
        private System.Windows.Forms.Panel panel_Sheet_Index;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button_Scan_Sheet_Index;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Button button_Sheet_Index;
    }
}

